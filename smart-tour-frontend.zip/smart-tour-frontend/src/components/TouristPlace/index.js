import './style.css';
import React, { useState, useEffect } from 'react';
//import {Link} from 'react-router-dom';

// function GuideModel(props) {
//     //const [state,setState]=useState(props.state);
//     //const [city,setCity]=useState(props.city);
//     const [guide,setGuide]=useState([]);
//     useEffect(()=>{
//         fetch(`http://localhost:9999/guide/${props.state}/${props.city}`,{
//             method:"GET",
//             credentials:"include",
//         })
//         .then(res=>res.json())
//         .then(res=>{
//             console.log("Guide"+ res);
//             setGuide(res);
//         })
//     },[]);
    
//     return (
//         <>
//              <div className="modal fade bd-example-modal-lg" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
//                 <div className="modal-dialog modal-lg">
//                     <div className="modal-content">
//                         <div className="modal-header">
//                             <h5 className="modal-title" id="exampleModalLongTitle">Guide</h5>
//                             <button type="button" className="close" data-dismiss="modal" aria-label="Close">
//                                 <span aria-hidden="true">&times;</span>
//                             </button>
//                         </div>
//                         <div className="modal-body">
//                             <table className="table">
//                                 <thead>
//                                     <tr className="table-primary">
//                                         <th scope="col">Sr No.</th>
//                                         <th scope="col">Name</th>
//                                         <th scope="col">Mobile No.</th>
//                                         <th scope="col">Language</th>
//                                     </tr>
//                                 </thead>
//                                 <tbody>
//                                     {
//                                         guide.map((value,index)=>(
//                                             <tr key={index} className="table-danger">
//                                             <th scope="row">{index+1}</th>
//                                         <td>{value.name}</td>
//                                         <td>{value.mobile}</td>
//                                         <td>{value.language}</td>
//                                             </tr>
//                                         ))
//                                     }
                                  
//                                 </tbody>
//                             </table>

//                         </div>

//                     </div>
//                 </div>
//             </div> 
//         </>
//     );
// }

function TouristPlace() {
    const [loading, setLoading] = useState(false);
    const [state,setState]=useState("Utter Pradesh");
    const [city,setCity]=useState("Ayodhya");
    const [place, setPlace] = useState([]);
    const [guide,setGuide]=useState([]);
    
    useEffect(() => {
        setLoading(true);
        fetch(`http://localhost:9999/tourPlaceDetails`,{
            method:"GET",
            credentials:"include",
        })
            .then(r => r.json())
            .then(res => {
                setPlace(res)
                setLoading(false)
            });
    }, []);

    const searchPlace=()=>{
        fetch(`http://localhost:9999/tourPlaceDetails/${state}/${city}`,{
            method:"GET",
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setPlace(res);
        })
    }
    const guideHandler=()=>{
        
        fetch(`http://localhost:9999/guide/${state}/${city}`,{
            method:"GET",
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log("Guide1"+ res);
            setGuide(res);
        })
    }
    if (loading && place.length === 0) {
        return(<div className="d-flex mt-5 justify-content-center ">
        <div className="text-danger mb-5 " role="status">
        <span className="visually-hidden h2">Loading...</span>
        </div>
        </div>)
    }

    const isDisabled=()=>state.trim().length===0 || city.trim().length===0;
    return (
        <>      
         {/* Guide Model */}
        <div className="modal fade bd-example-modal-lg" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-lg">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="exampleModalLongTitle">Guide</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <table className="table">
                                <thead>
                                    <tr className="table-primary">
                                        <th scope="col">Sr No.</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Mobile No.</th>
                                        <th scope="col">Language</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        guide.map((value,index)=>(
                                            <tr key={index} className="table-danger">
                                            <th scope="row">{index+1}</th>
                                        <td>{value.name}</td>
                                        <td>{value.mobile}</td>
                                        <td>{value.language}</td>
                                            </tr>
                                        ))
                                    }
                                    
                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>
            </div>   
            <div className="container mt-3">
                <div className="row">
                    <div className="col-md-4 fixed">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <span className="head-txt">Search Tourist Place Here</span>
                            <form method="POST">
                                <label className="form-label mt-3">Choose State<span style={{color:"red"}}>*</span></label>
                                <input className="form-control" list="statelistOptions" id="stateList" value={state} onChange={(e)=>setState(e.target.value)} placeholder="Type to search state here" />
                                <datalist id="statelistOptions">
                                    <option value="Utter Pradesh" />
                                    <option value="Uttrakhand" />
                                    <option value="Delhi" />
                                    <option value="Punjab" />
                                    <option value="Haryana" />
                                </datalist>

                                <label className="form-label mt-3">Choose City<span style={{color:"red"}}>*</span></label> {/*for="cityList"*/}
                                <input className="form-control" list="citylistOptions" id="cityList" value={city} onChange={(e)=>setCity(e.target.value)} placeholder="Type to search city here" />
                                <datalist id="citylistOptions">
                                    <option value="San Francisco" />
                                    <option value="New York" />
                                    <option value="Seattle" />
                                    <option value="Los Angeles" />
                                    <option value="Chicago" />
                                </datalist>
                            </form>
                             <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="button" className="btn btn-danger mt-4 " disabled={isDisabled()} onClick={guideHandler} data-toggle="modal" data-target=".bd-example-modal-lg" >Find Guide</button>
                                <button type="button" className="btn btn-danger mt-4 ml-2" disabled={isDisabled()} onClick={searchPlace}>Search Place</button>
                            </div>
                            {/* <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="button" className="btn btn-danger mt-5" data-toggle="modal" data-target=".bd-example-modal-lg">Find Guide</button>
                            </div> */}
                        </div>
                    </div>
                    <div className="col-md-8">
                        {place.map((post, index) => {
                    return (
                        
                    <div key={index} className="row shadow-lg p-3 mb-5 bg-white rounded">
                    
                        <div className="col-6"><img style={{width:"300px",height:"300px"}} src={"/tour-place/"+post.imageUrl} alt=""/></div>
                        <div className="col-6">
                            <div className="head-txt">{post.city}</div>
                            <p>{post.description}<span><a href={post.url} target="_blank" rel="noreferrer">Wikipedia</a></span></p>
                            {/* <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="button" className="btn btn-danger mt-5" data-toggle="modal" data-target=".bd-example-modal-lg">Find Guide</button>
                            </div> */}
                        </div>
                    </div>
                    
                    )
            })}
                    </div>
                </div>
            </div>
        </>
    );
}


export default TouristPlace;