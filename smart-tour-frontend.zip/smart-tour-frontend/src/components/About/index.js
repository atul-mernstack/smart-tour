function About(){
    return(
        <>
        
        <div className="container mt-4 mb-5" style={{height:"500px"}}>
                <div className="row">
                    <div className="col-12">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <h3 className="head-txt mb-1 text-center">About Smart Tour</h3><br></br>
                            <p><b>Smart tourism</b> is an important component of smart city.
                            Tourism is one of the major components of economic growth for communities worldwide.
                             A key requirement of tourism has been to attract more and more tourists from different
                              parts of the world. Smart tourism refers to the application of information and
                               communication technology, such similar to the smart cities, for developing
                                innovative tools and approaches to improve tourism.<br></br><br></br>
                                 Smart tourism is reliant on core technologies such as ICT, mobile communication,
                                  cloud computing, artificial intelligence, and virtual reality.
                                   It supports integrated efforts at a destination to find innovative
                                    ways to collect and use data derived from physical infrastructure,
                                     social connectedness and organizational sources (both government and non-government),
                                      and users in combination with advanced technologies to increase efficiency, 
                                      sustainability, experiences.<br></br> <br></br>
                                      The information and communication technology tools used for smart
                                       tourism include IoT, mobile communication, cloud computing, and
                                        artificial intelligence. It combines physical, informational,
                                         social, and commercial infrastructure of tourism with such tools
                                          to provide smart tourism opportunities. The principles of smart
                                           tourism lie at enhancing tourism experiences, improve the efficiency
                                            of resource management, maximize destination competitiveness with an 
                                            emphasis on sustainable aspects.<br></br><br></br> It should also gather and distribute information to facilitate efficient allocation of tourism resources and integrate tourism supplies at a micro and macro level ensuring that the benefits are well distributed.</p>
                        </div>
                    </div>
                </div>
        </div> 
        </>
    );
}

export default About;