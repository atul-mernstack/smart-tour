import './style.css';
function BookedRoom() {
    return (
        <>
            <div className="row shadow-lg p-3 mb-5 bg-white rounded">
                <div className="col-12">
                    <div className="head-txt shadow-lg p-1 mb-2 bg-danger rounded">Booked Rooms</div>
                    <div className="hotel-name mb-2">Hotel Alaknanda, Haridwar</div>
                    <table className="table">
                                <thead>
                                    <tr className="table-primary">
                                        <th scope="col">Sr No.</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Mobile No.</th>
                                        <th scope="col">E-mail</th>
                                        <th scope="col">Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr className="table-danger">
                                        <th scope="row">1</th>
                                        <td>Mark</td>
                                        <td>Otto</td>
                                        <td>@mdo</td>
                                        <td>@mdo</td>
                                    </tr>
                                    <tr className="table-light">
                                        <th scope="row">2</th>
                                        <td>Jacob</td>
                                        <td>Thornton</td>
                                        <td>@fat</td>
                                        <td>@fat</td>
                                    </tr>
                                </tbody>
                            </table>
                    <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="button" className="btn btn-danger mt-1">Logout</button>
                    </div>
                </div>
            </div>
        </>
    );
}
export default BookedRoom;