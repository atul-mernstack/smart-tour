import { useEffect, useState } from 'react';
import {Link} from 'react-router-dom';
import './style.css';

export default function SignIn(props){
    const [userName,setUserName]=useState('');
    const [password,setPassword]=useState('');
    const [msg,setMsg]=useState(false);
    //const [error,setError]=useState();

    useEffect(()=>{
        props.setHotelUrl(true);
        props.setFooter(false);
    });
    const loginHandler=()=>{
        fetch("http://localhost:9999/signin",{
            method:"POST",
            body:JSON.stringify({userName:userName,password:password}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>{
            if(res.ok) {
                return { success: true };
              } else {
                return res.json()
              }
        })
        .then(res=>{
            if(res.success===true){
                setUserName('');
                setPassword('');
                setMsg(true);
            }
            else{
                //console.log(res.err);
                //setError(res.err);
            }
        });
    }
    const isDisabled=()=>userName.trim().length===0||password.trim().length===0;
    return(
        <>
        <div className="container mt-3">
                <div className="row justify-content-center">
                    <div className="col-8">
                        <div className="row shadow-lg p-3 mb-5 bg-white rounded">
                            <div className="col-md-6"><img src="/signin-img.jfif" alt=""/></div>
                            <div className="col-md-6">
                           
                        <h3 className="head-txt mb-3 text-center">User login</h3>
                        
                            <div className="form-group">
                                <label htmlFor="Usermobile" className="form-label"> Username<span style={{color:"red"}}>*</span> </label>
                                <input type="text" className="form-control " id="Usermobile" onChange={e=>setUserName(e.target.value)} value={userName} placeholder="Enter email"/>
                            </div>
                            
                            <div className="form-group">
                                <label htmlFor="Userpass" className="form-label"> Enter Password<span style={{color:"red"}}>*</span> </label>
                                <input type="Password" className="form-control " id="Userpass" onChange={e=>setPassword(e.target.value)} value={password} placeholder=" Enter Password"/>
                            </div>
                            <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                                <button type="button" className="btn btn-danger mt-1" disabled={isDisabled()} onClick={loginHandler}>Login</button>
                                
                            </div>
                            {msg?<span style={{color:"green"}}>Login Successfull! <Link to="/Online-hotels-booking">click here</Link> to go ahead.</span>:null}
                        </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
        
        </>
    );
}
