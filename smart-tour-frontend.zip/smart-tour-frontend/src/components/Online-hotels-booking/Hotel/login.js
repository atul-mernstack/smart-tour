import {Link} from 'react-router-dom';
import { useState } from 'react';
export default function Login(props) {
    //const [msg,setMsg]=useState();
    //const [error,setError]=useState();
    const [userName,setUserName]=useState("");
    const [password,setPassword]=useState('');
     const signupHandler = () => {
         props.setSignup(true);
         props.setLogin(false);
     }

     const loginHandler = () => {
        fetch("http://localhost:9999/signin",{
            method:"POST",
            body:JSON.stringify({userName:userName,password:password}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>{
            if(res.ok) {
                return { success: true };
              } else {
                return res.json()
              }
        })
        .then(res=>{
            if(res.success===true){
                props.setRoomShow(true);
                //props.setBookNow(true);
                props.setLogin(false);
                //setMsg(true);
            }
            else{
                //console.log(res.err);
                //setError(res.err);
            }
        });
         
     }
     const isDisabled=()=>userName.trim().length===0 || password.trim().length===0;
    return (
         <>
            <div className="row shadow-lg p-3 mb-5 bg-white rounded">
                 <div className="col-6">
                     <img src="/signin-img.jfif" alt=""></img>
                 </div>
                 <div className="col-6">
                     <h3 className="head-txt mb-3 text-center">User login</h3>
                     <div className="form-group">
                         <label htmlFor="Usermobile" className="form-label"> Username<span style={{color:"red"}}>*</span></label>
                         <input type="text" className="form-control " id="Usermobile" onChange={e=>setUserName(e.target.value)} value={userName} placeholder="Enter email" />
                     </div>

                     <div className="form-group">
                         <label htmlFor="Userpass" className="form-label"> Enter Password<span style={{color:"red"}}>*</span></label>
                         <input type="Password" className="form-control " id="Userpass" onChange={e=>setPassword(e.target.value)} value={password} placeholder=" Enter Password" />
                     </div>
                     <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                         <button type="button" className="btn btn-danger mt-1" disabled={isDisabled()} onClick={loginHandler}>Login</button>

                     </div>
                     <span>If new user than<Link to="#" className="btn ml-0" onClick={signupHandler} >click here</Link></span>
                 </div>
                 </div>
         </>
     );
 }