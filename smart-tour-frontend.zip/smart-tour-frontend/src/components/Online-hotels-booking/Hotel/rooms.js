import React, { useEffect, useState } from 'react'
//import {useHistory} from 'react-router-dom';
export default function Rooms(props) {
    // const { checkInDate, checkOutDate, hotelId, hotelName } = props;
    const [rooms, setRooms] = useState([]);
    //const [userId, setUserId] = useState(undefined);
    const [noOfRoom, setNoOfRoom] = useState(1);
    const [category, setCategory] = useState('Single');
    //const [msg, setMsg] = useState('');
    //const [error, setError] = useState();
    //const history=useHistory();
    useEffect(() => {
        fetch(`http://localhost:9999/rooms/${props.hotelId}`, {
            credentials: "include",
        })
            .then(res => res.json())
            .then(res => {
                setRooms(res);
                
            })
    });
    const handleSubmit = (roomId, roomType, priceSingle, priceDouble) => {
        

        fetch('http://localhost:9999/userinfo', {
            credentials: "include",
        })
            .then(res => res.json())
            .then(res => {
                
                if (res.userName !== null && res.userName !== undefined) {
                    props.setRoomType(roomType);
                    props.setPriceSingle(priceSingle);
                    props.setPriceDouble(priceDouble);
                    props.setRoomId(roomId);
                    props.setCategory(category);
                    props.setNoOfRoom(noOfRoom);
                    props.setLogin(false);
                    props.setRoomShow(false);
                    props.setBookNow(true);
                    props.setSignup(false);
                    props.setUserId(res.userName);
                    
                    //setMsg(true);
                }
                else {
                    props.setLogin(true);
                    //history.push("/Online-hotels-booking/sing-in");
                    props.setRoomShow(false);
                    props.setBookNow(false);
                    props.setSignup(false);
                    
                    //setError(res.err);
                }
            });

    }


    return (
        <>
            {rooms.map((rooms, index) => {
                return (
                    <div key={index}>
                        <div  className="row shadow-lg p-3 mb-5 bg-white rounded" id="room">
                            {/* <button type="btn btn-primary" onClick={change}>on Click</button> value={noOfRoom} value={person}*/}
                            <div className="col-6 room-list"><img src={"/room-img/" + rooms.roomImgUrl} alt=""/></div>
                            <div className="col-6">
                <div className="head-txt shadow-lg p-1 mb-2 bg-danger rounded" id="roomType" >{rooms.roomType}(Single :   {rooms.priceSingle} | Double :   {rooms.priceDouble})</div>
                                {/* <div id="price">Price : 1500Rs{noOfRoom}/{person}</div> */}
                                {rooms.isAvailable ? (<form>
                                <label htmlFor="roomList" className="form-label mt-1">No. of Rooms</label>
                                    <input className="form-control" list="roomOptions" id="roomList" onChange={(e) => setNoOfRoom(e.target.value)} placeholder="No. of Rooms..." />
                                    <datalist id="roomOptions">
                                          
                                        <option value="1" />
                                        <option value="2" />
                                        <option value="3" />
                                        <option value="4" />
                                        <option value="5" />
                                    </datalist>
                                    <label htmlFor="catList" className="form-label mt-2">Room Type</label>
                                    <input className="form-control" list="catOptions" id="catList" onChange={(e) => setCategory(e.target.value)} placeholder="Single/Double..." />
                                    <datalist id="personOptions">
                                        <option value="Single" />
                                        <option value="Double" />
                                    </datalist>
                                    <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="button" className="btn btn-danger mt-3" id="btn-click"
                                            onClick={e => handleSubmit(rooms.roomId, rooms.roomType, rooms.priceSingle, rooms.priceDouble)}>BookNow
                                      </button>
                                    </div>
                                </form>) : <h1 className="mt-5 mb-5" styel={{ fontWeight: "bold" }}>Sold out</h1>}

                                {/* { signIn?<Link className="link-style text-light" to="/Online-hotels-booking/BookNow">Book Now</Link>
                            :<Link className="link-style text-light" to="/Online-hotels-booking/sign-in">Book Now</Link>} */}

                            </div>
                        </div>
                    </div>
                );
            })}

        </>
    );
}


