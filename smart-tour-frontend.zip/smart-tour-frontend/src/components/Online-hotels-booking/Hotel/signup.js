import {Link} from 'react-router-dom';
import React, {useState} from 'react';
export default function Signup(props) {
     const [msg, setMsg] = useState(false);
     //const [error,setError]=useState();
     const [name,setName]=useState('');
     const [email,setEmail]=useState('');
     const [password,setPassword]=useState('');
     const [mobile,setMobile]=useState('');
     const [address,setAddress]=useState('');
     const loginHandler = () => {
         props.setLogin(true);
         props.setSignup(false);
     }

     const signUpHandler = () => {
        fetch("http://localhost:9999/signup",{
            method:"POST",
            body:JSON.stringify({name:name,email:email,password:password,mobile:mobile,address:address}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>{
            if(res.ok) {
                return { success: true };
              } else {
                return res.json()
              }
        })
        .then(res=>{
            if(res.success===true){
                setMsg(true);
            }
            else{
                //console.log(res.err);
                //setError(res.err);
            }
        });
         //setMsg(true);
     }

     const isDisabled=()=>name.trim().length===0||email.trim().length===0||password.trim().length===0||
    mobile.trim().length===0||address.trim().length===0;
     return (
         <>
             <div className="shadow-lg p-3 mb-5 bg-white rounded">
                 <h3 className="head-txt mb-3 text-center">New Registration</h3>
                 <div className="row">
                     <div className="col-6">
                         <div className="form-group">
                             <label htmlFor="Username" className="form-label"> Name<span style={{color:"red"}}>*</span> </label>
                             <input type="text" className="form-control " id="Username" onChange={e=>setName(e.target.value)} value={name} placeholder="Name" />
                         </div>
                         <div className="form-group">
                             <label htmlFor="Useremail" className="form-label"> Email Id<span style={{color:"red"}}>*</span> </label>
                             <input type="text" className="form-control " id="Useremail" onChange={e=>setEmail(e.target.value)} value={email} placeholder="Email Id" />
                         </div>
                         <div className="form-group">
                             <label htmlFor="Userpass" className="form-label"> Create Password<span style={{color:"red"}}>*</span> </label>
                             <input type="Password" className="form-control " id="Userpass" onChange={e=>setPassword(e.target.value)} value={password} placeholder=" Create Password" />
                         </div>
                     </div>
                     <div className="col-6">
                         <div className="form-group">
                             <label htmlFor="Usermobile" className="form-label"> Mobile No.<span style={{color:"red"}}>*</span> </label>
                             <input type="text" className="form-control " id="Usermobile" onChange={e=>setMobile(e.target.value)} value={mobile} placeholder="Mobile No." />
                         </div>
                         <div className="form-group">
                             <label htmlFor="Useraddress" className="form-label"> Address<span style={{color:"red"}}>*</span> </label>
                             <input type="text" className="form-control " id="Useraddress" onChange={e=>setAddress(e.target.value)} value={address} placeholder="Address" />
                         </div>
                         {/* <div className="form-group">
                             <label for="Userconfirmpass" className="form-label"> Confirm Password<span style={{color:"red"}}>*</span> </label>
                             <input type="Password" className="form-control " id="Userconfirnpass" onChange={e=>setConfirmPass(e.target.value)} value={confirmPass} placeholder="Confirm Password" />
                         </div> */}
                     </div>
                     <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                         <button type="button" className="btn btn-danger mt-1 ml-3" disabled={isDisabled()} onClick={signUpHandler}>Sign Up</button>
                     </div>
                     {msg ?
                         <span style={{ color: "green" }}>Sign Up Successfully!<Link className="btn" to="#" onClick={loginHandler}>for login to click here</Link></span>
                         : <Link className="btn" to="#" onClick={loginHandler}>For login to click here</Link>
                     }
                 </div>
             </div>
         </>
     )
 }