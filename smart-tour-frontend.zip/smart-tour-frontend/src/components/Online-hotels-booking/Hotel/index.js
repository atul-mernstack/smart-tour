import './style.css';
import { useState, useEffect } from 'react';
import BookNow from '../BookNow';
import Rooms from './rooms';
import Login from './login';
import Signup from './signup';



function Hotel(props) {
         const [roomShow, setRoomShow] = useState(false);
         const [login, setLogin] = useState(false);
         const [signup, setSignup] = useState(false);
         const [bookNow, setBookNow] = useState(false);
         const [hotel, setHotel] = useState([]);
         const [loading, setLoading] = useState(true);
         const [userId, setUserId] = useState("");
         const [roomId,setRoomId]=useState('');
         const [hotelId,setHotelId]=useState('');
         const [hotelName,setHotelName]=useState('');
         const [category,setCategory]=useState('');
         const [noOfRoom,setNoOfRoom]=useState('');
         const [roomType,setRoomType]=useState('');
         const [priceSingle,setPriceSingle]=useState('');
         const [priceDouble,setPriceDouble]=useState('');
    //     console.log("id   ", props.match.params.Id);
    
    const id = props.match.params.Id;
    useEffect(() => {
        
        fetch(`http://localhost:9999/hotel/${id}`, {
            credentials: "include",
        })
            .then(r => r.json())
            .then(res => {
                setHotel(res)
                setHotelId(res._id);
                setHotelName(res.hotelName);
                
                setLoading(false);
            })
            .catch(err => {
                //console.log(err);
            })

    });

         if (loading && hotel.length === 0) {
             return (
                 <>
                <div className="d-flex mt-5 justify-content-center ">
                     <div className="text-danger " role="status">
                         <span className="visually-hidden h2">Loading...</span>
                     </div>
                 </div>
                 </>
             )
         }

    return (
        <>
            <div className="row shadow-lg p-3 mb-5 bg-white rounded">
                <div className="col-6 room-list"><img src={"/hotel-img/" + hotel.imageUrl} alt="" /></div>
                <div className="col-6">
                    <div className="head-txt shadow-lg p-1 mb-2 bg-danger rounded">{hotel.hotelName}</div>
                    <div className="address">{hotel.address}</div>
                    <div className="rooms popup-content">
                        <p className="inc">Amenities</p>
                        <div className="icm1">

                            <img src="/aminitiesIcon/Conference Hall.jpg" title="Conference Hall" alt="" className="amico" />
                            <img src="/aminitiesIcon/Doctor On Call.png" title="Doctor On Call" alt="" className="amico" />
                            <img src="/aminitiesIcon/Laundry.png" title="Laundry" alt="" className="amico" />
                            <img src="/aminitiesIcon/Parking.jpg" title="Parking" alt="" className="amico" />
                            <img src="/aminitiesIcon/Restaurant.png" title="Restaurant" alt="" className="amico" />
                            <img src="/aminitiesIcon/Travel Desk.png" title="Travel Desk" alt="" className="amico" />
                        </div>
                    </div>
                    <p className="desc">{hotel.description}</p>
                    <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="button" className="btn btn-danger mt-1" onClick={()=>{setRoomShow(true);
                             setLogin(false);
                             setBookNow(false)
                             setSignup(false)}} >Choose Rooms</button>
                    </div>
                </div>
            </div>
             {roomShow ? <Rooms hotelId={hotel._id}
                    hotelName={hotel.title} setRoomShow={setRoomShow} setLogin={setLogin} setBookNow={setBookNow}
                    setSignup={setSignup} setUserId={setUserId} setRoomId={setRoomId} 
                    setCategory={setCategory} setNoOfRoom={setNoOfRoom} setRoomType={setRoomType} 
                    setPriceSingle={setPriceSingle} setPriceDouble={setPriceDouble}/>
                    : null}
                {
                    login?<Login setSignup={setSignup} setLogin={setLogin} setBookNow={setBookNow} setRoomShow={setRoomShow}/>:null
                }
                {
                    signup?<Signup setSignup={setSignup} setLogin={setLogin}/>:null
                }
                {
                    bookNow?<BookNow userId={userId}  hotelId={hotelId} roomId={roomId} category={category}
                     noOfRoom={noOfRoom} roomType={roomType} priceSingle={priceSingle} priceDouble={priceDouble}
                     hotelName={hotelName}/>:null
                }  

        </>
    );
}

export default Hotel;