import { useState,useEffect } from 'react';
export default function Support(props){
    const [name,setName]=useState('');
    const [mobile,setMobile]=useState('');
    const [email,setEmail]=useState('');
    const [query,setQuery]=useState('');
    const [msg,setMsg]=useState(false);
    useEffect(()=>{
        props.setFooter(false);
        props.setHotelUrl(true);
    });

    const submitHandler=()=>{
        fetch('http://localhost:9999/support',{
            method:"POST",
            body:JSON.stringify({name:name,mobile:mobile,email:email,query:query}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            setMsg(true);
            setEmail('');
            setMobile('');
            setName('');
            setQuery('');
            setTimeout(()=>setMsg(false),2000);
            //console.log(res);
        })
        .catch(err=>{
            //console.log(err);
        })
    }
    const isDisabled=()=>name.trim().length===0||mobile.trim().length===0||email.trim().length===0||query.trim().length===0;
    return(<>
        <div className="container">
                <div className="row">
                    <div className="col-md-12 mt-3">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                        <h2 className="text-center mb-4 bg-danger p-2">Support/Enquery</h2>
                        <div className="row">
                            <div className="col-md-6">
                            <div className="form-group">
                                <label htmlFor="Userpass" className="form-label"> Name<span style={{color:"red"}}>*</span> </label>
                                <input type="text" className="form-control " id="Userpass" onChange={e=>setName(e.target.value)} value={name} placeholder=" Name"/>
                            </div>
                            <div className="form-group">
                                <label htmlFor="Usermobile" className="form-label"> Mobile No.<span style={{color:"red"}}>*</span> </label>
                                <input type="text" className="form-control " id="Usermobile" onChange={e=>setMobile(e.target.value)} value={mobile} placeholder="Mobile No."/>
                            </div>
                            <div className="form-group">
                                <label htmlFor="Useremail" className="form-label"> Email Id<span style={{color:"red"}}>*</span> </label>
                                <input type="text" className="form-control " id="Useremail" onChange={e=>setEmail(e.target.value)} value={email} placeholder="Email Id"/>
                            </div>
                            
                            <div className="form-group">
                                <label htmlFor="Query" className="form-label"> Query/Suggestion<span style={{color:"red"}}>*</span> </label>
                                <textarea type="Password" className="form-control " id="Query" onChange={e=>setQuery(e.target.value)} value={query} placeholder=" Query/Suggestion"/>
                            </div>
                            <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                                <button type="button" className="btn btn-danger mt-1" disabled={isDisabled()} onClick={submitHandler}>Continue</button>
                                {msg?<p style={{color:"green", fontStyle:"italic"}}>Msg send successfully!</p>:null}
                            </div>
                            </div>
                            <div className="col-md-6 mt-3">
                            <div className="shadow-lg p-3 mb-5 bg-white rounded">
                                <div style={{marginLeft:170}}>
                                <img src="/support.png" style={{height:170}} alt=""/>
                                </div>
                                <div className="text-center">
                                <h2 className="mt-3">Talk to us for more</h2>
                                <h4>05432567921/05432368922</h4>
                                <h4>+91-9415019807 / +91-9415904323</h4>
                            </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    
                    
                </div>
            </div>
        </>
        );
}