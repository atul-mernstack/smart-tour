import React, {useState, useEffect} from 'react';
import {Table} from 'reactstrap';
export default function ViewHistory(props){
    const [loggedOut, setLoggedOut]=useState(false);
    const [viewHistory,setViewHistory]=useState([]);
    const {setHotelUrl,setFooter}=props;
    useEffect(()=>{
        //props.setHotelUrl(true);
        // props.setFooter(false);
        setHotelUrl(true);
        setFooter(false);
        fetch('http://localhost:9999/userinfo', {
            credentials: "include",
        })
            .then(response => response.json())
            .then(response => {
                fetch("http://localhost:9999/bookNow",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            setViewHistory(res.filter((value,indx)=>value.emailId===response.userName));
        })
            })
        
    });

    const logoutHandler=()=>{
        fetch('http://localhost:9999/logout', { 
            credentials: 'include'
        })
        .then(r => {
        if(r.ok) {
        setLoggedOut(true);
        setViewHistory([]);
      }
    })
    }
    return(<>
    <div className="container mt-3">
        <div className="row shadow-lg p-3 mb-5 bg-white rounded justify-content-center">
                <div className="col">
                    
                   <p style={{color:"green"}}>After login you can view history!</p>
                            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Name</th>
          <th>Guest Name</th>
          <th>Hotel Name</th>
          <th>Room Type</th>
          <th>No. Of Room</th>
          <th>Mobile No.</th>
          <th>Address</th>
          <th>Price</th>
          <th>BookedOn</th>
        </tr>
      </thead>
      <tbody>
        
            {viewHistory.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.name}</td>
                <td>{value.guestName}</td>
                <td>{value.hotelName}</td>
                <td>{value.roomType}</td>
                <td>{value.noOfRoom}</td>
                <td>{value.mobile}</td>
                <td>{value.address}</td>
                <td>{value.price}</td>
                <td>{value.bookedOn}</td>
        </tr>
                )
            })}
            </tbody>
            </Table>
                    <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                        <button type="button" className="btn btn-danger mt-1" onClick={logoutHandler}>Logout</button>
                    </div>
                    {loggedOut?<div style={{color:"green"}}>Logout Successfully!</div>:null}
                </div>
            </div>
            </div>
        </>
        );
}