import './style.css';
import Hotels from './Hotels';
import Hotel from './Hotel';
import {BrowserRouter,Link, Route, Switch} from 'react-router-dom';
import { useEffect, useState } from 'react';
function OnlineHotels(props){
    const [city,setCity]=useState("");
    const [checkIn,setCheckIn]=useState('');
    const [checkOut,setCheckOut]=useState('');
    //const [hotel, setHotel]=useState();
    //const history=useHistory();
    //const searchHotel=()=>{
        //console.log("Main");     
        //history.push(`/Online-hotels-booking/${city}`);
            //  fetch(`http://localhost:9999/hotels/${city}`)
            //      .then(r => r.json())
            //      .then(res => {
            //          setHotel(res)
            //          console.log(res);
            //      })
            //      .catch(err=>{
            //          console.log(err);
            //      })
           
    //}
    useEffect(()=>{
        props.setFooter(false);
        props.setHotelUrl(true);
    });

    const isDisabled=()=>city.trim().length===0 || checkIn.trim().length===0 || checkOut.trim().length===0;
    return(
        <BrowserRouter>
<div className="container mt-4">
                <div className="row">
                    <div className="col-md-4">
                        <div className="shadow-lg p-3 mb-3 bg-white rounded">
                          <span className="head-txt">Search Hotels Here</span>  
                            <form method="POST">
                                <label htmlFor="cityList" className="form-label">Choose City<span style={{color:"red"}}>*</span></label>
                                <input className="form-control" list="citylistOptions" id="cityList" value={city} onChange={(e)=>setCity(e.target.value)} placeholder="Type to search city here"/>
                                    <datalist id="citylistOptions">
                                        <option value="Ayodhya"/>
                                        <option value="Varanasi"/>
                                        <option value="Lucknow"/>
                                        <option value="Mathura"/>
                                        
                                    </datalist>
                                    <label htmlFor="checkIn" className="form-label mt-3">Check-In Date<span style={{color:"red"}}>*</span></label>
                             <input type="date" className="form-control" id="checKIn" name="checkIn" value={checkIn} onChange={(e)=>setCheckIn(e.target.value)}/>
                             <label htmlFor="checkOut" className="form-label mt-3">Check-Out Date<span style={{color:"red"}}>*</span></label>
                             <input type="date" className="form-control" id="checKOut" name="checkOut" value={checkOut} onChange={(e)=>setCheckOut(e.target.value)}/>
                            </form>
                            <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                             <Link to={`/Online-hotels-booking/${city}`}>
                                <button type="button" className="btn btn-danger mt-4" disabled={isDisabled()}
                                >Search Hotel</button>
                             </Link> 
                            
                            </div>
                        </div>
                        
                    </div> 
                    <div className="col-md-8 mt-0">
                        
                        <Switch>
                            <Route exact path="/Online-hotels-booking" component={Hotels}/>
                            <Route exact path="/Online-hotels-booking/:city" component={Hotels}/>
                            <Route exact path="/Online-hotels-booking/hotels/:Id" component={Hotel}/>                           
                        </Switch>
                        
                    </div>
                </div>
            </div>
        </BrowserRouter>
    );
}
export default OnlineHotels;