import { useEffect, useState } from "react";
import {useHistory} from 'react-router-dom';
export default function BookNow(props){
    const [name,setName]=useState('');
    const [mobile,setMobile]=useState('');
    const [address,setAddress]=useState('');
    const [totalPrice,setTotalPrice]=useState(0);
    const [guestName,setGuestName]=useState('');
    const [msg,setMsg]=useState(false);
    const [room,setRoom]=useState([]);
    const [noOfRoom,setNoOfRoom]=useState('');
//<BookNow userId={userId}  hotelId={hotelId} roomId={roomId} person={person}
//noOfRoom={noOfRoom} roomType={roomType} priceSingle={priceSingle} priceDouble={priceDouble}
//hotelName={hotelName}/>
const history=useHistory();
const diffInMs   = new Date(localStorage.getItem('checkOut')) - new Date(localStorage.getItem('checkIn'));
const diffInDays = diffInMs / (1000 * 60 * 60 * 24);
        //console.log("localStorage-diff", diffInDays);
const priceCalculation=(category,priceSingle,priceDouble,noOfRoom)=>{
    let price=1;
    if(category.toUpperCase()==="SINGLE"){
        price=diffInDays*noOfRoom*priceSingle;
    }
    else{
        price=diffInDays*noOfRoom*priceDouble;
    }
    setTotalPrice(price);
}

// const hotelId=props.hotelId;
// const roomId=props.roomId;
// const roomType=props.roomType;
// const noOfRoom=props.noOfRoom;
// const category=props.category;
// const priceSingle=props.priceSingle;
// const priceDouble=props.priceDouble;

    useEffect(()=>{
        fetch("http://localhost:9999/rooms",{
             credentials:"include",
         })
         .then(res=>res.json())
         .then(res=>{
             setRoom(res)
            let presentRoom=res.filter((value,index)=>value.hotelId===props.hotelId
         &&value.roomId===props.roomId&&value.roomType===props.roomType)[0].availableRoom;
         let bookedRoom=presentRoom>=props.noOfRoom?(props.noOfRoom):(presentRoom);
         //console.log("Payment     ",presentRoom)
        setNoOfRoom(bookedRoom);
             priceCalculation(props.category,props.priceSingle,props.priceDouble,bookedRoom);//availableRoom
            })
   });
  
    const paymentHandler=()=>{
         let presentRoom=room.filter((value,index)=>value.hotelId===props.hotelId
         &&value.roomId===props.roomId&&value.roomType===props.roomType)[0].availableRoom;
         let availableRoom=presentRoom>=noOfRoom?(presentRoom-noOfRoom):0;
         //console.log("Payment     ",availableRoom)
        // setNoOfRoom(availableRoom);
        //let isAvailable = availableRoom>0?true:false;
        //let availableRoom=0;
        let isAvailable = availableRoom>0?true:false;
        //console.log(availableRoom,isAvailable);
        //console.log("localStorage.getItem('checkIn')  ", localStorage.getItem('checkIn'));
        fetch(`http://localhost:9999/bookNow`,{
            method:"POST",
            body:JSON.stringify({hotelName:props.hotelName,hotelId:props.hotelId,roomId:props.roomId,
            name:name,guestName:guestName,mobile:mobile,emailId:props.userId,address:address,roomType:props.roomType,
            price:totalPrice,noOfRoom:props.noOfRoom, checkIn:localStorage.getItem('checkIn'),checkOut:localStorage.getItem('checkOut')}),
            headers:{
                "Content-Type":"application/json"
            },
            credentials:"include",
        })
            .then(r => r.json())
            .then(res => {
               //console.log("Response  ",res);
               setName('');
               setGuestName('');
               setMobile('');
               setAddress('');
               setMsg(true);
               sendMail();//mail sending
               fetch("http://localhost:9999/rooms",{
                method:"PUT",
                body:JSON.stringify({hotelId:props.hotelId,roomId:props.roomId,roomType:props.roomType,noOfRoom:availableRoom,isAvailable:isAvailable}),
                headers:{
                    "Content-Type":"application/json",
                },
                credentials:"include",
            })
            .then(res=>res.json())
            .then(res=>{
                //console.log(res);
            })
                history.push("/Online-hotels-booking");
               setTimeout(()=>setMsg(false),5000);
            })
            .catch(err=>{
                //console.log(err);
            })
     }

     const sendMail=()=>{
         fetch('http://localhost:9999/sendmail',{
             method:"POST",
             body:JSON.stringify({name:name,guestName:guestName,mobile:mobile,address:address,
                price:totalPrice,email:props.userId,noOfRoom:noOfRoom, roomCat:props.roomType,days:diffInDays}),
             headers:{
                 "Content-Type":"application/json",
             },
             credentials:"include"
         })
     }
     const isDisabled=()=>name.trim().length===0||guestName.trim().length===0||mobile.trim().length===0||address.trim().length===0;
            
    return(
    <>
    <div className="row shadow-lg p-3 mb-5 bg-white rounded">
                <div className="col-6">
                <div className="mb-3">
                                <label htmlFor="fullName" className="form-label">Full Name<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="fullName" onChange={e=>setName(e.target.value)} value={name} placeholder="Full Name"/>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="mobileNo" className="form-label">Mobile No.<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="mobileNo" onChange={e=>setMobile(e.target.value)} value={mobile} placeholder="Mobile No."/>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="address" className="form-label">Address<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="address" onChange={e=>setAddress(e.target.value)} value={address} placeholder="Address"/>
                            </div>
                            {/* <div className="mb-3">
                                <label for="person" className="form-label">No Of Person<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="person" readOnly value={props.category} placeholder="No Of Person"/>
                            </div> */}
                            <div className="mb-3">
                                <label htmlFor="price" className="form-label">Price(+GST)<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="price" readOnly value={totalPrice} placeholder="Price"/>
                            </div>
                            <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                    <button type="button" className="btn btn-danger" disabled={isDisabled()} onClick={paymentHandler}>Payment</button>
                    {msg?<p style={{color:"green", marginLeft:"1px"}}>Booked your room!</p>:null}
                    </div>
                                </div>
                                <div className="col-6">
                                <div className="mb-3">
                                <label htmlFor="guestName" className="form-label">Guest Name<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="guestName" onChange={e=>setGuestName(e.target.value)} value={guestName} placeholder="Guest Name"/>
                            </div>
                                <div className="mb-3">
                                <label htmlFor="email" className="form-label">Email address<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="email" readOnly value={props.userId} placeholder="Email Address"/>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="roomType" className="form-label">Room Type<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="roomType" readOnly value={`${props.roomType}(${props.category})`} placeholder="Room Type"/>
                            </div>
                            <div className="mb-3">
                                <label htmlFor="noOfRoom" className="form-label">No. Of Room<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="noOfRoom" readOnly value={noOfRoom} placeholder="No. Of Room"/>
                            </div>
                                </div>
                                
                            </div>
                        
                            
            
            
    </>
    );
}