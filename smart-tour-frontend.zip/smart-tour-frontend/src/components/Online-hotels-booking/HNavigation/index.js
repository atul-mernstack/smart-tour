import React from 'react';
import {Link} from 'react-router-dom';
import './style.css';
function HNavigation(props) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-danger">
  <div className="container-fluid">
    <Link className="navbar-brand brand-txt" to="/Online-hotels-booking">ONLINE HOTELS BOOKING</Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse justify-content-end mr-5 mx-5" id="navbarText">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0 ">
        {/* <li className="nav-item">
          <Link className="nav-link active nav-txt" aria-current="page" to="/">HOME</Link>
        </li> */}
        <li className="nav-item">
          <Link className="nav-link nav-txt" to="/Online-hotels-booking/sing-up">SIGN UP</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link nav-txt" to="/Online-hotels-booking/sing-in">SIGN IN</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link nav-txt" to="/Online-hotels-booking/support">SUPPORT</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link nav-txt" to="/Online-hotels-booking/ViewHistory">VIEW HISTORY</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link nav-txt" to="/Online-hotels-booking/contact-us">CONTACT US</Link>
        </li>
      </ul>
      
    </div>
  </div>
</nav>
  );
}

export default HNavigation;
