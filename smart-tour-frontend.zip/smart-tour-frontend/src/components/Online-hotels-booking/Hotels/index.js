import './style.css';
import { Link} from 'react-router-dom';
import { useEffect, useState } from 'react';

function Hotels(props) {
    const [hotels, setHotels] = useState([])
    const [loading, setLoading] = useState(true);
    const [model,setModel]=useState(false);
    const city=props.match.params.city;
    
    const isNullOrUndefined = (value)=>value===null || value===undefined;
    const flag=isNullOrUndefined(city);
    
    useEffect(() => {
        flag?withoutParams():withParams(city);
    }, [city,flag]);
    const withParams=(city)=>{
        fetch(`http://localhost:9999/hotels/${city}`,{
            credentials:"include",
        })
            .then(r => r.json())
            .then(res => {
                setHotels(res)
                setLoading(false);
            })
            .catch(err=>{
                //console.log(err);
            })
    }
    const withoutParams=()=>{
        fetch(`http://localhost:9999/hotels`,{
            credentials:"include",
        })
            .then(r => r.json())
            .then(res => {
                setHotels(res)
                setLoading(false);
            })
            .catch(err=>{
                //console.log(err);
            })
    }
    if (loading && hotels.length === 0) {
        return (
            <div className="d-flex mt-5 justify-content-center ">
                <div className="text-danger " role="status">
                    <span className="visually-hidden h2">Loading...</span>
                </div>
            </div>
        )
    }

    return (
        <>

            <div className="row hotels-container">
                {hotels.map((hotels, index) => {
                    return (
                        <div key={index}>
                            <div className="checkin-checkout-model"><CheckInOutModel  hotelId={hotels._id} setModel={setModel}/></div>{/*setModel={setModel}*/}
                            <div className="shadow p-1 mb-1 bg-white rounded hotels-item"><img style={{width:"200px", height:"200px"}} src={"/hotel-img/"+hotels.imageUrl} alt=""/>
                                {/* <div className="hotels-name mt-2">{hotels.city}</div> */}
                                <div className="hotels-name mt-2 mb-2">{hotels.hotelName}</div>
                                <div className="d-grid gap-2 d-md-flex justify-content-md-center">
                                    {/* onClick={()=>setModel(false)}*/}
                                    <button type="button" className="btn btn-danger" data-toggle="modal" data-target=".bd-example-modal-lg">
                                     {model?<Link className="link-style text-light"  to={`/Online-hotels-booking/hotels/${hotels._id}`}>{hotels.city}</Link>
                                       :`${hotels.city}`}</button>                                     
                                </div>
                            </div>
                        </div>
                    )
                })}
            </div>
        </>
    );
}

function CheckInOutModel(props) {
    const [checkIn,setCheckIn]=useState('');
    const [checkOut,setCheckOut]=useState('');
    //const history=useHistory();
    const viewHotel = () => {
       
        
        localStorage.setItem("checkIn",checkIn);
        localStorage.setItem("checkOut",checkOut);
        props.setModel(true);
        //history.push(`/Online-hotels-booking/hotels/${props.hotelId}`);
    }
    const diffInMs   = new Date(checkOut) - new Date(checkIn);
    const diffInDays = diffInMs / (1000 * 60 * 60 * 24);
    //console.log("diff date", diffInDays);
    const isDisabled=()=>checkIn.trim().length===0 || checkOut.trim().length===0|| diffInDays <=0;
    return (
        <>
            <div className="modal fade bd-example-modal-lg" tabIndex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-md">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="exampleModalLongTitle">CheckIn/CheckOut</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body justify-content-start">
                            <form><label htmlFor="checkIn" className="form-label">Check-In Date<span style={{color:"red"}}>*</span></label>
                                <input type="date" className="form-control" id="checKIn" onChange={e=>setCheckIn(e.target.value)} value={checkIn} name="checkIn" />
                                <label htmlFor="checkOut" className="form-label mt-3">Check-Out Date<span style={{color:"red"}}>*</span></label>
                                <input type="date" className="form-control" id="checKOut" onChange={e=>setCheckOut(e.target.value)} value={checkOut} name="checkOut" />
                            </form>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-danger" data-dismiss="modal">Cancle</button>

                            <button type="button" className="btn btn-danger" data-dismiss="modal" disabled={isDisabled()}  onClick={viewHotel}>
                                Save changes
                            </button>

                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
export default Hotels;