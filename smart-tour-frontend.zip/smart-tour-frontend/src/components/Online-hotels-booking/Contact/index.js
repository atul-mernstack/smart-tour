import React, {useState, useEffect} from 'react';
import {Table} from 'reactstrap';
export default function Contact(props){
    const [hotelContact,setHotelContact]=useState([]);
    const {setHotelUrl,setFooter}=props;
    useEffect(()=>{
        // props.setHotelUrl(true);
        // props.setFooter(false);
        setHotelUrl(true);
        setFooter(false);
        fetch("http://localhost:9999/hotelContact",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            setHotelContact(res);
        })
    });
    
    return(
        
    <>
    <div className="container mt-3">
                <div className="row">
                    <div className="col-12">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <h4 className="head-txt mb-3 p-3 bg-danger text-center">Contact Us</h4>
                            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>City</th>
          <th>Hotel Name</th>
          <th>Contact No.</th>
          <th>Landline No.</th>
          <th>Email Id</th>
          <th>Address</th>
        </tr>
      </thead>
      <tbody>
        
            {hotelContact.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.city}</td>
                <td>{value.hotelName}</td>
                <td>{value.contactNo}</td>
                <td>{value.landlineNo}</td>
                <td>{value.emailId}</td>
                <td>{value.address}</td>
        </tr>
                )
            })}
            </tbody>
            </Table>
                            
                        </div>
                    </div>
                </div>
        </div> 
        </>
        );
}