import {useState} from 'react';
const Rnf=()=>{
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [password,setPassword]=useState('');
    const [mobile,setMobile]=useState('');
    const [address,setAddress]=useState('');
    const [uname,setUname]=useState('');
    const [upass,setUpass]=useState('');
    const register=()=>{

    }
    const login=()=>{
        
    }
    const isDisabled=()=>name.trim().length===0||email.trim().length===0||password.trim().length===0||
    mobile.trim().length===0||address.trim().length===0;

    return(
        <>
<div className="container mt-3">
                <div className="row justify-content-center">
                    <div className="col-md-10">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            
                            <div className="row">
                                <div className="col-md-6">
                                <h3 className="head-txt mb-3 text-center">New Registration</h3>
                                    <div className="form-group">
                                        <label for="Username" className="form-label"> Name<span style={{color:"red"}}>*</span></label>
                                        <input type="text" className="form-control " id="Username" onChange={e=>setName(e.target.value)} value={name} placeholder="Name"/>
                                    </div>
                                    <div className="form-group">
                                <label for="Useremail" className="form-label"> Email Id<span style={{color:"red"}}>*</span></label>
                                <input type="email" className="form-control " id="Useremail" onChange={e=>{setEmail(e.target.value)}} value={email} placeholder="Email Id"/>
                                
                                </div>
                                <div className="form-group">
                                <label for="Usermobile" className="form-label"> Mobile No.<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control " id="Usermobile" onChange={e=>setMobile(e.target.value)} value={mobile} placeholder="Mobile No."/>
                                </div>
                                <div class="form-group">
                                <label for="Useraddress" className="form-label"> Address<span style={{color:"red"}}>*</span></label>
                                <input type="email" className="form-control " id="Useraddress" onChange={e=>setAddress(e.target.value)} value={address} placeholder="Address"/>
                                </div>
                                <div class="form-group">
                                <label for="Userpass" className="form-label"> Create Password<span style={{color:"red"}}>*</span></label>
                                <input type="Password" className="form-control " id="Userpass" onChange={e=>setPassword(e.target.value)} value={password} placeholder=" Create Password"/>
                                </div>
                                <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                                <button type="button" className="btn btn-danger mt-1" disabled={isDisabled()} onClick={register}>Register</button>
                                </div>
                                </div>
                                <div className="col-md-6">
                                <h3 className="head-txt mb-3 text-center">user Login</h3>
                                <div className=""><img style={{marginLeft:"50px", marginBottom:"30px"}} src="/signin-img.jfif" alt=""/></div>
                                <div className="form-group">
                                <label for="Usermobile" className="form-label"> Username<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control " id="Username" onChange={e=>setUname(e.target.value)} value={uname} placeholder="Username"/>
                                </div>
                                <div class="form-group">
                                <label for="Useraddress" className="form-label"> Password<span style={{color:"red"}}>*</span></label>
                                <input type="email" className="form-control " id="Userpass" onChange={e=>setUpass(e.target.value)} value={upass} placeholder="Password"/>
                                </div>
                                <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                                <button type="button" className="btn btn-danger mt-1" onClick={login}>User Login</button>
                                </div>
                                </div>

                            </div>                          
                                
                           
                        </div>
                    </div>
                </div>
        </div> 
        </>
    )
}

export default Rnf;