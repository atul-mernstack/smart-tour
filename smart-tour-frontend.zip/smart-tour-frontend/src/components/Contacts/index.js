import { useState } from 'react';
import './style.css';
function Contacts() {
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [mobile,setMobile]=useState('');
    const [address,setAddress]=useState('address');
    const [message,setMessage]=useState('');
    const [msg,setMsg]=useState(false);
    const queryHandler=()=>{
        fetch('http://localhost:9999/tourContact',{
            method:"POST",
            body:JSON.stringify({name:name,email:email,mobile:mobile,address:address,message:message}),
            headers:{"Content-Type":"application/json"},
            credentials:"include"
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);            
                setMsg(true);
                setName('');
            setEmail('');
            setAddress('');
            setMobile('');
            setMessage('');
               setTimeout(()=>clearMsg(),2000);
        })
        .catch(err=>{
            //console.log(err);
        })
    }

    const clearMsg=()=>{                      
            setMsg(false);
    }
    const isDisabled=()=>name.trim().length===0 || email.trim().length===0 || mobile.trim().length===0 || address.trim().length===0
    || message.trim().length===0
    return (
        <>
            <div className="container mt-3">
                <div className="row">
                    <div className="col-12">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <img style={{width:"100%", height:"400px"}} src={'/contact.jpg'} alt=""/>
                            {/* <span className="head-txt">Google Map</span>

                            <div><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28492.600434984302!2d82.18165820219669!3d26.7898124330208!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399a07937e6d2823%3A0x5fc8f683b17f222b!2sAyodhya%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1608333395505!5m2!1sen!2sin" width="100%" height="450" frameBorder="0" style={{ border: 0 }} allowFullScreen="" aria-hidden="false" tabIndex="0"></iframe></div> */}
                        </div>
                    </div>
                </div>
                <div className="row mt-2">
                    <div className="col-md-6">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <h3 className="head-txt">Director General</h3>
                            <div className="mt-3">
                                <strong>Address : </strong>
                                <span>Directorate of Tourism, Uttar Pradesh<br></br>
                                    Rajarshi Purushottam Das Tandon Paryatan Bhavan<br></br>
                                    C-13, Vipin Khand, Gomti Nagar,<br></br>
                                    For Lucknow, Uttar Pradesh</span><br></br><br></br>
                                    <strong>Phone : </strong>
                                    <span>+91-522-2308993</span><br></br><br></br>
                                    <strong>For Tourism Policy Related Query Contact on this Email id</strong><br></br>
                                    <span>uptourismpolicy@gmail.com ,<br></br> investment.uptourism@gmail.com</span><br></br><br></br>
                                    <strong>Fax : </strong>
                                    <span>91-522-2308937</span> <br></br>
                                    <strong>E-mail Id : </strong>
                                    <span>dg.upt1@gmail.com</span> <br></br>
                                    <strong>Working Days : </strong>
                                    <span>Monday to Friday</span>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <span className="head-txt mb-5">Query/Suggestion</span>
                            <div className="mb-3">
                                <label htmlFor="fullName" className="form-label">Full Name<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="fullName" onChange={(e)=>setName(e.target.value)} value={name} placeholder="Full Name"/>
                            </div>
                            <div className="mb-2">
                                <label htmlFor="email" className="form-label">Email address<span style={{color:"red"}}>*</span></label>
                                <input type="email" className="form-control" id="email" onChange={(e)=>setEmail(e.target.value)} value={email} placeholder="Email Address"/>
                            </div>
                            <div className="mb-2">
                                <label htmlFor="mobileNo" className="form-label">Mobile No.<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="mobileNo" onChange={(e)=>setMobile(e.target.value)} value={mobile} placeholder="Mobile No."/>
                            </div>
                            {/* <div className="mb-3">
                                <label for="address" className="form-label">Address<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="address" onChange={(e)=>setAddress(e.target.value)} value={address} placeholder="Address"/>
                            </div> */}
                            <div className="mb-2">
                                <label htmlFor="message" className="form-label">Message<span style={{color:"red"}}>*</span></label>
                                <input type="text" className="form-control" id="message" onChange={(e)=>setMessage(e.target.value)} value={message} placeholder="Message"/>
                            </div>
                            <div className="d-grid gap-2 d-md-flex">
                                <button type="button" className="btn btn-danger mt-1" disabled={isDisabled()} onClick={queryHandler}>send</button>
                            </div>
                            {msg?<p style={{color:"green"}}>Message send! </p>:null}
                            </div>
                        </div>
                    </div>
                </div>        
        </>
    );
}

export default Contacts;