import './style.css';
import Pagination from '../Pagination';
import {useEffect,useState} from 'react';
function Gallery(){
    const [posts, setPosts] = useState([])
    const [loading, setLoading] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [postsPerPage] = useState(6)
    useEffect(() => {
        setLoading(true);
        //fetch('https://jsonplaceholder.typicode.com/posts')
        fetch('http://localhost:9999/gallery')
            .then(r => r.json())
            .then(res => {
                //console.log("Data  " + res);
                setPosts(res)
                setLoading(false)
            });
    }, [])

    if (loading && posts.length === 0) {
        return(<div className="d-flex mt-5 justify-content-center ">
        <div className="text-danger mb-5 " role="status">
        <span className="visually-hidden h2">Loading...</span>
        </div>
        </div>)
    }

    //Get current posts
    const indexOfLastPost = currentPage * postsPerPage;
    const indexOfFirstPost = indexOfLastPost - postsPerPage;
    const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost)
    const howManyPages = Math.ceil(posts.length / postsPerPage)
    return(
        <>        
        <div className="img-container">
        {currentPosts.map((post, index) => {
                return (
            <div key={index} className="shadow p-3 mb-3 bg-white rounded img-item "><img style={{width:"300px", height:"250px"}} src={"/gallery/"+post.imageUrl} alt=""/></div>
                )}
        )}
        </div>
        <div className="container">
        <Pagination pages={howManyPages} setCurrentPage={setCurrentPage} />
        </div>
        
        </>
    );
}

export default Gallery;