function Dos(){
    return(
        <>
        <div className="container mt-3">
                <div className="row">
                    <div className="col-12">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <h3 className="head-txt mb-1 text-center">Do's & Don'ts</h3><br></br>
                            <h4>Here are some guidelines whom you should follow and avoid while visiting India.</h4>
                            <h4>Do's</h4>
                            <ul>
<li>Respect the traditions and culture of Uttar Pradesh and its people.</li>
<li>Wear descent dresses while visiting religious places.</li>
<li>Exchange money only at official exchange counters and banks.</li>
<li>Only hire guides that are approved by the government and have license.</li>
<li>Spend your money wisely.</li>
<li>Learn few words of local language that are commonly used here.</li>
<li>Buy items that depict the true essence of Uttar Pradesh and are not available elsewhere.</li>
</ul>
                            <h4>Don'ts</h4>
                            <ul>
<li>Do not litter, help us in maintaining our cities clean and green.</li>
<li>Do not take any photographs that may make people embarrassed.</li>
<li>Don’t smoke, don't drink alcohol or don't&nbsp; use drugs at public places and religious spots.</li>
<li>Don’t touch or harass animals and support conservation of animals by paying entrance fees to parks and conserved sites.</li>
<li>Don’t buy crafts or products made from skin of endangered animals.</li>
<li>Do not drive on Indian roads unless you are well-aware about Indian roads and drive to the left of the road</li>
<li>Do not give any offensive comment about any religion; it could be controversial.</li>
<li>Do not buy or book hotels/bus/air/railway tickets through strangers or unauthorized agents.</li>
<li>Do not hire transportation from unlicensed operators.</li>
</ul>
<p><strong>Follow these guidelines and make your journey happy and joyful.</strong></p>
                        </div>
                    </div>
                </div>
        </div>
        </>
    )
}
export default Dos;