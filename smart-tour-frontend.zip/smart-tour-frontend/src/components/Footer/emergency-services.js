
function Emergency(){
    return(
        <>
            <div className="container mt-3">
                <div className="row">
                    <div className="col-12">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                            <h3 className="head-txt mb-2 text-center">Emergency Services</h3><br></br>
                            <div class="col-lg-12 text-center"><strong>Police station:</strong> 100<br></br>
                             <strong>Ambulance:</strong> 108<br></br> <strong>Women Helpline:</strong> 1090<br></br>
                              <strong>Child Line:</strong> 1098<br></br> <br></br><br></br></div>
                        </div>
                    </div>
                </div>
        </div>
        </>
    )
}
export default Emergency;