import './style.css';
import {Link} from 'react-router-dom';
import { useState } from 'react';

 function Footer(){
const [mail,setMail]=useState('');
  const subscribe=()=>{
    if(mail.trim().length<=0){
      alert("Email Address is required.");
      setMail('');
    }
    else{
      alert("Subscribed successfully.");
      setMail('');
    }
  }
     return(
         <>
    <div className="main-footer mt-4">
      <div className="container">
        <div className="row">
          {/* Column1 */}
          <div className="col">
            <h3 style={{fontSize:"xx-large", fontWeight:"bold", fontStyle:"italic"}}>SMART TOUR</h3>
            <p className="list-unstyled">
              <li>Smart tour is an important
                 component of smart city. Tour
                  is one of the major components of economic growth for communities worldwide</li>
              <li><img src="/swach-bharat.png" alt="swach bharat"/></li>
            </p>
          </div>
          {/* Column2 */}
          <div className="col">
            <h4>Quick Access</h4>
            <ul className="list-unstyled">
              <li><Link className="link-txt text-light" to="/">Home</Link></li>
              <li><Link className="link-txt text-light" to="/about-us">About Us</Link></li>
              <li><Link className="link-txt text-light" to="/tourist-place">Tourist Place</Link></li>
              <li><Link className="link-txt text-light" to="/gallery">Gallery</Link></li>
              <li><Link className="link-txt text-light" to="/contact-us">Contact Us</Link></li>
            </ul>
          </div>
          {/* Column3 */}
          <div className="col">
            <h4>Other Info</h4>
            <ul className="list-unstyled">
              <li><Link className="link-txt text-light" to="/emergency-services">Emergency Services</Link></li>
              <li><Link className="link-txt text-light" to="/indiaweather.gov.in">Weather</Link></li>
              <li><Link className="link-txt text-light" to="/google.com/maps/@27.141237,80.8833819,7z">Map</Link></li>
              <li><Link className="link-txt text-light" to="/do's-and-don'ts">DOs & Don’ts</Link></li>
            </ul>
          </div>
          {/* Column4 */}
          <div className="col">
            <h4>Newsletter</h4>
           <ul className="list-unstyled">
            <div className="mb-3">
  <label htmlFor="formFile" className="form-label link-txt">Sign up for regular updates</label>
  <input className="form-control" type="text" id="formFile" onChange={e=>setMail(e.target.value)} value={mail} placeholder="Enter email address"/>
  
</div>
<div className="d-grid gap-2">
<button type="button" className="btn-lg" onClick={subscribe}>Subscribe</button>
</div>
            </ul>
          </div>
        </div>
        <hr />
        <div className="row">
          <p className="col-sm">
            &copy;{new Date().getFullYear()} SMART TOUR | All rights reserved |
            Terms Of Service | Privacy
          </p>
        </div>
      </div>
    </div>
         </>
     );
 }
 export default Footer;