import React,{useEffect, useState} from 'react';
import {Table} from 'reactstrap';
function BookNow(){
    const [bookedRoom,setBookedRoom]=useState([]);
    useEffect(()=>{
        fetch("http://localhost:9999/bookNow",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setBookedRoom(res);
        })
    },[]);
    return(
        <>
        {/* <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">BookNow</h3>
                        <Form>
                        <FormGroup>
                                <Label for="exampleEmail">Name</Label>
                                <Input type="email" name="email" id="exampleEmail" placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Guest Name</Label>
                                <Input type="email" name="email" id="exampleEmail" placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Mobile No.</Label>
                                <Input type="email" name="email" id="exampleEmail" placeholder="with a placeholder" />
                            </FormGroup>
                                <Label for="exampleEmail">Email</Label>
                                <Input type="email" name="email" id="exampleEmail" placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Text Area</Label>
                                <Input type="textarea" name="text" id="exampleText" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleFile">File</Label>
                                <Input type="file" name="file" id="exampleFile" />
                                <FormText color="muted">
                                    This is some placeholder block-level help text for the above input.
                                    It's a bit lighter and easily wraps to a new line.
                                </FormText>
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Text Area</Label>
                                <Input type="textarea" name="text" id="exampleText" />
                            </FormGroup>
                            <Button color="danger">Save</Button>
                        </Form>
                        
                    </div>
                </div>
            </div> */}
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Hotel Name</th>
          <th>Name</th>
          <th>Guest Name</th>
          <th>Mobile</th>
          <th>Email Id</th>
          <th>Room Type</th>
          <th>Price</th>
          <th>No Of Room</th>
          <th>CheckIn</th>
          <th>CheckOut</th>
          <th>isCheckOut</th>
          <th>BookedOn</th>
        </tr>
      </thead>
      <tbody>
        
            {bookedRoom.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.hotelName}</td>
                <td>{value.name}</td>
                <td>{value.guestName}</td>
                <td>{value.mobile}</td>
                <td>{value.emailId}</td>
                <td>{value.roomType}</td>
                <td>{value.price}</td>
                <td>{value.noOfRoom}</td>
                <td>{value.checkIn}</td>
                <td>{value.checkOut}</td>
                <td>{value.isCheckOut}</td>
                <td>{value.bookedOn}</td>
        </tr>
                )
            })}
            </tbody>
            </Table> 
        </>
    )
}
export default BookNow;