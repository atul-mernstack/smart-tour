import React,{useEffect,useState} from 'react';
import {Table, Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

function Hotels(){
    const [city,setCity]=useState();
    const [hotelName,setHotelName]=useState();
    const [hotelId,setHotelId]=useState();
    const [file,setFile]=useState();
    const [address,setAddress]=useState();
    const [desc,setDesc]=useState();
    const [hotel,setHotel]=useState([]);
    const cityHandler=(e)=>{setCity(e.target.value)};
    const hotelHandler=(e)=>{setHotelName(e.target.value)};
    const hotelIdHandler=(e)=>{setHotelId(e.target.value)};
    const imgHandler=(e)=>{setFile(e.target.files[0])};
    const addressHandler=(e)=>{setAddress(e.target.value)};
    const descHandler=(e)=>{setDesc(e.target.value)};
    const onSubmit=(e)=>{
        e.preventDefault();
        const formData=new FormData();
        formData.append('city',city);
        formData.append('hotelName',hotelName);
        formData.append('hotelId',hotelId);
        formData.append('file',file);
        formData.append('address',address);
        formData.append('desc',desc);
        fetch("http://localhost:9999/hotels",{
            method:"POST",
            body:formData,        
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setHotel([...hotel,res]);
        })
        .catch(err=>{
            //console.log(err);
        })
    }
    useEffect(()=>{
        fetch("http://localhost:9999/hotels",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log("useEffect "+res);
            setHotel(res);
        })
    },[]);
    const deleteHandler = (itemId,indx) => {
        const idToDelete = itemId;
        const itemIndx=indx;
        fetch(`http://localhost:9999/hotels/${idToDelete}`, {
          method: "DELETE", credentials: "include"  
        }).then((res) => {
          //console.log("Got successfully DELETE");
          hotel.splice(itemIndx, 1);
          setHotel([...hotel]);
          //console.log(res);
        });
      };
    return(
        <>
        <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">Hotels</h3>
                        <Form onSubmit={onSubmit}>
                            <FormGroup>
                                <Label for="exampleEmail">City</Label>
                                <Input type="text" name="email" id="exampleEmail" onChange={cityHandler} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Hotel Name</Label>
                                <Input type="text" name="email" id="exampleEmail" onChange={hotelHandler} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Hotel Id</Label>
                                <Input type="text" name="email" id="exampleEmail" onChange={hotelIdHandler} placeholder="HotelName@123" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleFile">Image</Label>
                                <Input type="file" name="file" id="exampleFile" onChange={imgHandler} />
                                <FormText color="muted">
                                    This is some placeholder block-level help text for the above input.
                                    It's a bit lighter and easily wraps to a new line.
                                </FormText>
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">Address</Label>
                                <Input type="text" name="email" id="exampleEmail" onChange={addressHandler} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Description</Label>
                                <Input type="textarea" name="text" id="exampleText" onChange={descHandler} />
                            </FormGroup>
                            <Button type="submit" color="danger">Save</Button>
                        </Form>
                        
                    </div>
                </div>
            </div>
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Id</th>
          <th>City</th>
          <th>Hotel Name</th>
          <th>Image</th>
          <th>Address</th>
          <th>Description</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        
            {hotel.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value._id}</td>
                <td>{value.city}</td>
                <td>{value.hotelName}</td>
                <td><img style={{width:"50px",height:"50px"}} src={"/hotel-img/"+value.imageUrl} alt=""/></td>
                <td>{value.address}</td>
                <td>{value.description}</td>
                <td>{value.date}</td>
                <td><Button type="button" color="danger" onClick={()=>deleteHandler(value._id, indx)}>Delete</Button></td>
        </tr>
                )
            })}
            </tbody>
            </Table>
        </>
    )
}
export default Hotels;