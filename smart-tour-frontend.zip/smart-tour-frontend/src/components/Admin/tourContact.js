import { useState, useEffect } from 'react';
import { Table } from 'reactstrap';
function TourContact(){
  const [tourContact,setTourContact]=useState([]);
  useEffect(()=>{
    fetch("http://localhost:9999/tourContact",{
        credentials:"include",
    })
    .then(res=>res.json())
    .then(res=>{
        //console.log(res);
        setTourContact(res);
    })
},[]);
    return(
        <>
<Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Name</th>
          <th>Mobile No</th>
          <th>Email Id</th>
          <th>Address</th>
          <th>Msg</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        
            {tourContact.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.name}</td>
                <td>{value.mobile}</td>
                <td>{value.email}</td>
                <td>{value.address}</td>
                <td>{value.msg}</td>
                <td>{value.date}</td>
        </tr>
                )
            })}
            </tbody>
            </Table>        </>
    )
}
export default TourContact;