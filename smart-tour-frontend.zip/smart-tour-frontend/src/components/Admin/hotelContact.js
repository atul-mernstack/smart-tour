import React, { useEffect, useState } from 'react';
import { Table, Button, Form, FormGroup, Label, Input} from 'reactstrap';
function HotelContact(){
    const [city, setCity]=useState('');
    const [hotelName, setHotelName]=useState('');
    const [contact, setContact]=useState('');
    const [landline, setLandline]=useState('');
    const [email, setEmail]=useState('');
    const [address, setAddress]=useState('');
    const [hotelContact,setHotelContact]=useState([]);
    const cityHandler=(e)=>{setCity(e.target.value);}
    const nameHandler=(e)=>{setHotelName(e.target.value)}
    const contactHandler=(e)=>{setContact(e.target.value)}
    const landlineHandler=(e)=>{setLandline(e.target.value)}
    const emailHandler=(e)=>{setEmail(e.target.value)};
    const addressHandler=(e)=>{setAddress(e.target.value)}
    const onSubmit=(e)=>{
        e.preventDefault();
        fetch("http://localhost:9999/hotelContact",{
            method:"POST",
            body:JSON.stringify({city:city,hotelName:hotelName,contactNo:contact,landlineNo:landline,emailId:email,address:address}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            setHotelContact([...hotelContact,res]);
            //console.log(res);
        })
        .catch(err=>{
            //console.log(err);
        })

        
    }
    useEffect(()=>{
        fetch("http://localhost:9999/hotelContact",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setHotelContact(res);
        })
    },[]);
    return(
        <>
    <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">Hotel Contact</h3>
                        <Form onSubmit={onSubmit}>
                            <FormGroup>
                                <Label for="city">City</Label>
                                <Input type="text" name="city" id="city" onChange={cityHandler} value={city} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="hotelName">Hotel Name</Label>
                                <Input type="text" name="hotelName" id="hotelName" onChange={nameHandler} value={hotelName} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="contact">Contact No.</Label>
                                <Input type="text" name="contact" id="contact" onChange={contactHandler} value={contact} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="landline">Landline No.</Label>
                                <Input type="text" name="landline" id="landline" onChange={landlineHandler} value={landline} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="email">Email Id</Label>
                                <Input type="email" name="email" id="email" onChange={emailHandler} value={email} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="address">Address</Label>
                                <Input type="text" name="address" id="address" onChange={addressHandler} value={address} placeholder="with a placeholder" />
                            </FormGroup>
                            
                            <Button type="submit" color="danger">Save</Button>
                        </Form>
                        
                    </div>
                </div>
            </div>
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>City</th>
          <th>Hotel Name</th>
          <th>Contact No.</th>
          <th>Landline No.</th>
          <th>Email Id</th>
          <th>Address</th>
        </tr>
      </thead>
      <tbody>
        
            {hotelContact.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.city}</td>
                <td>{value.hotelName}</td>
                <td>{value.contactNo}</td>
                <td>{value.landlineNo}</td>
                <td>{value.emailId}</td>
                <td>{value.address}</td>
        </tr>
                )
            })}
            </tbody>
            </Table>
        </>
    )
}
export default HotelContact;