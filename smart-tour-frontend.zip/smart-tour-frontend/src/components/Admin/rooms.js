import React,{useEffect,useState} from 'react';
import {Table, Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
export default function Rooms() {
    const [hotelId,setHotelId]=useState();
    const [roomId,setRoomId]=useState();
    const [roomType,setRoomType]=useState();
    const [file,setFile]=useState();
    const [priceSingle,setPriceSingle]=useState();
    const [priceDouble,setPriceDouble]=useState();
    const [totalRoom,setTotalRoom]=useState();
    const [room,setRoom]=useState([]);
    const hotelIdHandler=(e)=>{setHotelId(e.target.value)};
        const roomIdHandler=(e)=>{setRoomId(e.target.value)};
        const roomTypeHandler=(e)=>{setRoomType(e.target.value)};
        const imageHandler=(e)=>{setFile(e.target.files[0])};
        const priceSingleHandler=(e)=>{setPriceSingle(e.target.value)};
        const priceDoubleHandler=(e)=>{setPriceDouble(e.target.value)};
        const totalRoomHandler=(e)=>{setTotalRoom(e.target.value)};
    const onSubmit=(e)=>{
        e.preventDefault();
        const formData=new FormData();
        formData.append('hotelId',hotelId);
        formData.append('roomId',roomId);
        formData.append('roomType',roomType);
        formData.append('file',file);
        formData.append('priceSingle',priceSingle);
        formData.append('priceDouble',priceDouble);
        formData.append('totalRoom',totalRoom);
        fetch("http://localhost:9999/rooms",{
            method:"POST",
            body:formData,
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            console.log(res);
            setRoom([...room,res]);
        })
        .catch(err=>{
            console.log(err);
        })
    }
    useEffect(()=>{
        fetch("http://localhost:9999/rooms",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setRoom(res);
        })
    },[]);
    const deleteHandler = (itemId,indx) => {
        const idToDelete = itemId;
        const itemIndx=indx;
        fetch(`http://localhost:9999/rooms/${idToDelete}`, {
          method: "DELETE", credentials: "include"  
        }).then((res) => {
          //console.log("Got successfully DELETE");
          room.splice(itemIndx, 1);
          setRoom([...room]);
          //console.log(res);
        });
      };

    return (
        <>
            <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">Room Details</h3>
                        <Form onSubmit={onSubmit}>
                            <FormGroup>
                                <Label for="exampleEmail">Hotel Id</Label>
                                <Input type="text" name="email" id="exampleEmail" onChange={hotelIdHandler} placeholder="Hotel Obj Id" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Room Id</Label>
                                <Input type="text" name="text" id="exampleText" onChange={roomIdHandler} placeholder="RoomType@123" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Room Types</Label>
                                <Input type="text" name="text" id="exampleText" onChange={roomTypeHandler}/>
                                    {/* <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                </Input> */}
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleFile">Image</Label>
                                <Input type="file" name="file" id="exampleFile" onChange={imageHandler}/>
                                <FormText color="muted">
                                    This is some placeholder block-level help text for the above input.
                                    It's a bit lighter and easily wraps to a new line.
                                </FormText>
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Price Single</Label>
                                <Input type="number" name="text" id="exampleText" onChange={priceSingleHandler}/>
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Price Double</Label>
                                <Input type="number" name="text" id="exampleText" onChange={priceDoubleHandler} />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Total Room</Label>
                                <Input type="number" name="text" id="exampleText" onChange={totalRoomHandler}/>
                            </FormGroup>
                            <Button type="submit" color="danger">Save</Button>
                        </Form>
                    </div>
                </div>
            </div>
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Hotel Id</th>
          <th>Room Id</th>
          <th>Room Type</th>
          <th>Image</th>
          <th>Single(RS)</th>
          <th>Double(Rs)</th>
          <th>Total</th>
          <th>Available Room</th>
          <th>CheckIn</th>
          <th>CheckOut</th>
          <th>Availability</th>
        </tr>
      </thead>
      <tbody>
        
            {room.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.hotelId}</td>
                <td>{value.roomId}</td>
                <td>{value.roomType}</td>
                <td><img style={{width:"50px",height:"50px"}} src={"/room-img/"+value.roomImgUrl} alt=""/></td>
                <td>{value.priceSingle}</td>
                <td>{value.priceDouble}</td>
                <td>{value.totalRoom}</td>
                <td>{value.availableRoom}</td>
                <td>{value.checkIn}</td>
                <td>{value.checkOut}</td>
                <td>{value.isAvailable}</td>
                <td><Button type="button" color="danger" onClick={()=>deleteHandler(value._id, indx)}>Delete</Button></td>
        </tr>
                )
            })}
            </tbody>
            </Table>
        </>
    )
}
