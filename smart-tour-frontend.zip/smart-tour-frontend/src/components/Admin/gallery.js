import React,{useState, useEffect} from 'react';
import {Table, Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
//import PUBLIC_URL from '../../../public/uploads';
function Gallery(){
    const [file,setFile]=useState('');
    const [title,setTitle]=useState('');
    const [gallery,setGallery]=useState([]);
    
    const imgHandler=(e)=>{
        setFile(e.target.files[0]);
    }
    const titleHandler=(e)=>{
        setTitle(e.target.value);
    }
    const onSubmit=(e)=>{
        e.preventDefault();

        const formData = new FormData() 
        
        //     headers: {
        //       "Content-Type": "multipart/form-data",
        //     },
        //     credentials:"include"
        
            formData.append('file', file);
            formData.append('title',title);
            
            fetch('http://localhost:9999/gallery', {
              method: 'POST',
              body:formData,              
            })
            .then(response => response.json())
            .then(result => {
              //console.log('Success:', result);
              setGallery([...gallery,result]);
            })
            .catch(error => {
              //console.error('Error:', error);
            });   
            
    }
    useEffect(()=>{
        fetch("http://localhost:9999/gallery",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setGallery(res);
        })
    },[]);

    const deleteHandler = (itemId,indx) => {
        const idToDelete = itemId;
        const itemIndx=indx;
        fetch(`http://localhost:9999/gallery/${idToDelete}`, {
          method: "DELETE", credentials: "include"  
        }).then((res) => {
          //console.log("Got successfully DELETE");
          gallery.splice(itemIndx, 1);
          setGallery([...gallery]);
          //console.log(res);
        });
      };
    return(
        <>
        <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">Gallery</h3>
                        {/* <Form action="/gallery" method="post" id="GalleryForm" role="form" encType="multipart/form-data">                             */}
                        <Form onSubmit={onSubmit}>
                            <FormGroup>
                                <Label for="exampleFile">Image</Label>
                                <Input type="file" name="galleryImg" id="exampleFile" onChange={imgHandler} />
                                <FormText color="muted">
                                    This is some placeholder block-level help text for the above input.
                                    It's a bit lighter and easily wraps to a new line.
                                </FormText>
                            </FormGroup>
                            <FormGroup>
                                <Label for="description">Description</Label>
                                <Input type="textarea" name="imgDescription" id="description" value={title} onChange={titleHandler} />
                            </FormGroup>
                            <Button type="submit" color="danger">Save</Button>
                        </Form>
                        
                    </div>
                </div>
            </div>
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Image</th>
          <th>Description</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        
            {gallery.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td><img style={{width:"50px",height:"50px"}} src={"/gallery/"+value.imageUrl} alt="" /></td>
                <td>{value.description}</td>
                <td>{value.date}</td>
                <td><Button type="button" color="danger" onClick={()=>deleteHandler(value._id, indx)}>Delete</Button></td>
        </tr>
                )
            })}
            </tbody>
            </Table>
        </>
    )
}
export default Gallery;