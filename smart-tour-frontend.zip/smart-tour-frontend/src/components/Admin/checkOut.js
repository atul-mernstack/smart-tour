import React, { useEffect, useState } from 'react';
import { Table, Button} from 'reactstrap';
function CheckOut(){
    const [bookedRoom,setBookedRoom]=useState([]);
    //const [msg,setMsg]=useState(false);
    const [room,setRoom]=useState([]);
    //const [availableRoom,setAvailableRoom]=useState(0);
    const checkOut=(hotelId,roomId,noOfRoom,roomType,indx)=>{
        let availableRoom=room.filter((value)=>value.hotelId===hotelId && value.roomId===roomId 
            && value.roomType===roomType)[0].availableRoom + noOfRoom;
            
            let isAvailable=true;
        fetch("http://localhost:9999/rooms",{
            method:"PUT",
            body:JSON.stringify({hotelId:hotelId,roomId:roomId,roomType:roomType,noOfRoom:availableRoom,isAvailable:isAvailable}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            fetch("http://localhost:9999/bookNow",{
            method:"PUT",
            body:JSON.stringify({hotelId:hotelId,roomId:roomId,isCheckOut:true}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            alert("Successfully checkout!");
            
            bookedRoom.splice(indx,1);
            setBookedRoom(bookedRoom);
            
        })
        })
        .catch(err=>{
            
        })

        
    }
    useEffect(()=>{
        fetch("http://localhost:9999/bookNow",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            
            setBookedRoom(res.filter((value,index)=>value.isCheckOut===false));
        })
        //get all rooms
         fetch("http://localhost:9999/rooms",{
             credentials:"include",
         })
         .then(res=>res.json())
         .then(res=>{
             setRoom(res);
             
         })
    },[]);
    return(
        <>
    {/* <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">Hotel Contact</h3>
                        
                        
                    </div>
                </div>
            </div> */}
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Hotel Name</th>
          <th>Name</th>
          <th>Guest Name</th>
          <th>Mobile</th>
          <th>Email Id</th>
          <th>Room Type</th>
          <th>Price</th>
          <th>No Of Room</th>
          <th>CheckIn</th>
          <th>CheckOut</th>
          <th>BookedOn</th>
        </tr>
      </thead>
      <tbody>
        
            {bookedRoom.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.hotelName}</td>
                <td>{value.name}</td>
                <td>{value.guestName}</td>
                <td>{value.mobile}</td>
                <td>{value.emailId}</td>
                <td>{value.roomType}</td>
                <td>{value.price}</td>
                <td>{value.noOfRoom}</td>
                <td>{value.checkIn}</td>
                <td>{value.checkOut}</td>
                <td>{value.bookedOn}</td>                
                <td><Button color="danger"  onClick={e=>{checkOut(value.hotelId,value.roomId,value.noOfRoom,value.roomType,indx)}}>CheckOut</Button></td>
                {/* {msg?<p style={{color:"green",fontStyle:"italic"}}>CheckOut successfully!</p>:null} */}
        </tr>
                )
            })}
            </tbody>
            </Table> 
        </>
    )
}
export default CheckOut;