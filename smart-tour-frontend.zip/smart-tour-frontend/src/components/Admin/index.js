import { useEffect, useState } from "react";
import Login from './login';

import Home from './home';
function Admin(props){
    const [home,setHome]=useState(true);
    useEffect(()=>{
        props.setAdmin(false);
    });
    
    return(
        <>
               
         {home?<Login setHome={setHome}/>:<Home/>}
       
        </>
    );
}

export default Admin;