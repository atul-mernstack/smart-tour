import { useEffect,useState } from 'react';
import { Table } from 'reactstrap';
function Support(){
  const [support, setSupport]=useState([]);
  useEffect(()=>{
    fetch("http://localhost:9999/support",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setSupport(res);
        })
  },[]);
    return(
      <>
      <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>Name</th>
          <th>Mobile No.</th>
          <th>Email Id</th>
          <th>Query</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        
            {support.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.name}</td>
                <td>{value.mobile}</td>
                <td>{value.emailId}</td>
                <td>{value.query}</td>
                <td>{value.submittedOn}</td>
          
        </tr>
                )
            })}
            </tbody>
            </Table>

        </>
    )
}
export default Support;