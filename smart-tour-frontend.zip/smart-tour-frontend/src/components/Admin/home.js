import React, { useState } from 'react';
import { TabContent, TabPane, Nav, NavItem, NavLink, Row, Col } from 'reactstrap';
import classnames from 'classnames';
import TourPlace from './tourPlace';
import Gallery from './gallery';
import State from './guide';
import TourContact from './tourContact';
import Hotels from './hotels';
import Rooms from './rooms';
import BookNow from './bookNow';
import Support from './support';
import HotelContact from './hotelContact';
import Signup from './signup';
import CheckOut from './checkOut';

function Home() {
    const [activeTab, setActiveTab] = useState('1');

  const toggle = tab => {
    if(activeTab !== tab) setActiveTab(tab);
  }
  
    return (
        <div className="container">
          <Nav tabs className="">
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '1' })}
                onClick={() => { toggle('1'); }}
              >
                Home
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '2' })}
                onClick={() => { toggle('2'); }}
              >
                Tour Place
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '3' })}
                onClick={() => { toggle('3'); }}
              >
                Gallery
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '4' })}
                onClick={() => { toggle('4'); }}
              >
                Guide
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '5' })}
                onClick={() => { toggle('5'); }}
              >
                Tour Contact
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '6' })}
                onClick={() => { toggle('6'); }}
              >
                Hotels
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '7' })}
                onClick={() => { toggle('7'); }}
              >
                Rooms
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '8' })}
                onClick={() => { toggle('8'); }}
              >
                BookedRoom
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '9' })}
                onClick={() => { toggle('9'); }}
              >
                Support
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '10' })}
                onClick={() => { toggle('10'); }}
              >
                Hotel Contact
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === '11' })}
                onClick={() => { toggle('11'); }}
              >
                CheckOut
              </NavLink>
            </NavItem>
          </Nav>
          <TabContent activeTab={activeTab}>
            <TabPane tabId="1">
              <Row>
                <Col sm="12">
                  {/* <h1>Tab 1 Contents</h1> */}
                  <Signup/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="2">
              <Row>
                <Col sm="12">
                  <TourPlace/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="3">
              <Row>
                <Col sm="12">
                  <Gallery/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="4">
              <Row>
                <Col sm="12">
                  <State/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="5">
              <Row>
                <Col sm="12">
                  <TourContact/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="6">
              <Row>
                <Col sm="12">
                  <Hotels/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="7">
              <Row>
                <Col sm="12">
                  <Rooms/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="8">
              <Row>
                <Col sm="12">
                  <BookNow/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="9">
              <Row>
                <Col sm="12">
                  <Support/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="10">
              <Row>
                <Col sm="12">
                  <HotelContact/>
                </Col>
              </Row>
            </TabPane>
            <TabPane tabId="11">
              <Row>
                <Col sm="12">
                  <CheckOut/>
                </Col>
              </Row>
            </TabPane>
          </TabContent>
          </div>
    )
}
export default Home;