import { useState, useEffect } from 'react';
import { Table, Button } from 'reactstrap';
function Signup() {
    const [signup, setSignup] = useState([]);
    useEffect(() => {
        fetch("http://localhost:9999/signup", {
            credentials: "include",
        })
            .then(res => res.json())
            .then(res => {
                //console.log(res);
                setSignup(res);
            })
    }, []);
    const deleteHandler = (itemId,indx) => {
        const idToDelete = itemId;
        const itemIndx=indx;
        fetch(`http://localhost:9999/signup/${idToDelete}`, {
          method: "DELETE", credentials: "include"  
        }).then((res) => {
          //console.log("Got successfully DELETE");
          signup.splice(itemIndx, 1);
          setSignup([...signup]);
          //console.log(res);
        });
      };
    return (
        <Table size="sm">
                <thead>
                    <tr>
                        <th>Sr No.</th>
                        <th>Name</th>
                        <th>Mobile No</th>
                        <th>Email Id</th>
                        <th>Address</th>
                        <th>Password</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    {signup.map((value, indx) => {
                        return (
                            <tr key={indx}>
                                <th scope="row">{indx + 1}</th>
                                <td>{value.name}</td>
                                <td>{value.mobile}</td>
                                <td>{value.email}</td>
                                <td>{value.address}</td>
                                <td></td> {/* {value.password} */}
                                <td>{value.createdOn}</td>
                                <td><Button color="danger" type="button" onClick={()=>deleteHandler(value._id,indx)}>Delete</Button></td>
                            </tr>
                        )
                    })}
                </tbody>
            </Table>        
    )
}
export default Signup;