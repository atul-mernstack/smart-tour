//import {Link} from 'react-router-dom';
import { useState } from "react";
function Login(props){
    //const [msg,setMsg]=useState(false);
    const [userPass,setUserPass]=useState(true);
    const [password,setPassword]=useState('');
    const [inputPass,setInputPass]=useState('');
    const [error,setError]=useState(false);
    const homeHandler=()=>{
        
        if(password===Number(inputPass)){
            props.setHome(false);
        }
        else{
            setError(true);
        }
    }

    const passHandler=()=>{
        const pass=Math.floor((Math.random()*1000000)+1);
        fetch('http://localhost:9999/admin-mail',{
            method:"POST",
            body:JSON.stringify({password:pass}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include"
        })
        .then(res=>res.json())
        .then(res=>{
            
            if(res.msg==='success'){
                setPassword(pass);
                setUserPass(false);
            }
        })
        .catch(err=>{
            
        })
        
    }
    return(
        <div className="container mt-3 login-style">
                <div className="row justify-content-center">
                    <div className="col-8">
                        <div className="row shadow-lg p-3 mb-5 bg-white rounded">
                            <div className="col-md-6"><img src="/signin-img.jfif" alt=""/></div>
                            <div className="col-md-6">
                           
                        <h3 className="head-txt mb-3 text-center">Admin login</h3>
                        
                            {/* <div class="form-group">
                                <label for="Usermobile" className="form-label"> Username </label>
                                <input type="text" className="form-control " id="Usermobile" placeholder="Enter email"/>
                            </div> */}
                            {/* {!userPass?((<div className="d-grid gap-2 d-md-flex justify-content-md-start">
                                <button type="button" className="btn btn-danger mt-1" onClick={homeHandler}>Generate Password</button>
                                
                            </div>)):(<div class="form-group">
                                <label for="Userpass" className="form-label"> Enter Password </label>
                                <input type="Password" className="form-control " id="Userpass" placeholder=" Enter Password"/>
                            </div>)} */}
                            {userPass?(<div className="d-grid gap-2 d-md-flex justify-content-md-start mt-5">
                                <button type="button" className="btn btn-danger mt-1" onClick={passHandler}>Generate Password</button>
                                
                            </div>):(<div><div className="form-group">
                                <label htmlFor="Userpass" className="form-label"> Enter Password </label>
                                <input type="Password" className="form-control " id="Userpass" onChange={e=>setInputPass(e.target.value)} value={inputPass} placeholder=" Enter Password"/>
                            </div>
                            {error?(<p style={{color:"green", fontStyle:'italic'}}>Password mismatch!</p>):null}
                            <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                            <button type="button" className="btn btn-danger mt-1" onClick={homeHandler}>Login</button>
                            
                        </div>
                        </div>
                        )}
                            
                            {/* {msg?<span style={{color:"green"}}>Login Successfull! <Link to="/Online-hotels-booking">click here</Link> to go ahead.</span>:null} */}
                        </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
    )
}
export default Login;