import React, { useState, useEffect } from 'react';
import {Table, Button, Form, FormGroup, Label, Input } from 'reactstrap';
function State(){
    const [city, setCity]=useState('');
    const [state,setState]=useState('');
    const [language,setLanguage]=useState();
    const [name,setName]=useState();
    const [mobile,setMobile]=useState();
    const [guide,setGuide]=useState([]);
    const statehandler=(e)=>{setState(e.target.value)}
    const cityHandler=(e)=>{setCity(e.target.value)}
    const languageHandler=(e)=>{setLanguage(e.target.value)}
    const nameHandler=(e)=>{setName(e.target.value)}
    const mobileHandler=(e)=>{setMobile(e.target.value)}
    const onSubmit=(e)=>{
        e.preventDefault();
        fetch("http://localhost:9999/guide",{
            method:"POST",
            body:JSON.stringify({state:state, city:city, language:language, name:name, mobile:mobile}),
            headers:{
                "Content-Type":"application/json",
            },
            credentials:"include",
        })
        .then(res=>res.json())  //ERROR
        .then((res)=>{
            //console.log(res);
            setGuide([...guide,res]);
        })
        .catch(err=>{
            //console.log(err);
        })
    }
    useEffect(()=>{
        fetch("http://localhost:9999/guide",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setGuide(res);
        })
    },[]);
    const deleteHandler = (itemId,indx) => {
        const idToDelete = itemId;
        const itemIndx=indx;
        fetch(`http://localhost:9999/guide/${idToDelete}`, {
          method: "DELETE", credentials: "include"  
        }).then((res) => {
          //console.log("Got successfully DELETE");
          guide.splice(itemIndx, 1);
          setGuide([...guide]);
          //console.log(res);
        });
      };
    return(
        <>
    <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">Guide Details</h3>
                        <Form onSubmit={onSubmit}>
                        <FormGroup>
                                <Label for="city">Name</Label>
                                <Input type="text" name="city" id="city" onChange={nameHandler} value={name} />
                            </FormGroup>
                            <FormGroup>
                                <Label for="city">Mobile No</Label>
                                <Input type="text" name="city" id="city" onChange={mobileHandler} value={mobile} />
                            </FormGroup>
                            <FormGroup>
                                <Label for="state">State</Label>
                                <Input type="text" name="state" id="state" onChange={statehandler} value={state} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="city">City</Label>
                                <Input type="text" name="city" id="city" onChange={cityHandler} value={city} />
                            </FormGroup>
                            <FormGroup>
                                <Label for="city">Language</Label>
                                <Input type="text" name="city" id="city" onChange={languageHandler} value={language} />
                            </FormGroup>                          
                            
                            
                            <Button type="submit" color="danger">Save</Button>
                        </Form>
                       
                    </div>
                </div>
            </div>
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>State</th>
          <th>City</th>
          <th>Name</th>
          <th>Mobile</th>
          <th>Language</th>
          
        </tr>
      </thead>
      <tbody>
        
            {guide.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.state}</td>
                <td>{value.city}</td>
                <td>{value.name}</td>
                <td>{value.mobile}</td>
                <td>{value.language}</td>
                <td><Button type="button" color="danger" onClick={()=>deleteHandler(value._id, indx)}>Delete</Button></td>
        </tr>
                )
            })}
            </tbody>
            </Table>
        </>
    )
}
export default State;