import React, { useState,useEffect } from 'react';
import {Table, Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
function TourPlace() {
    const [state,setState]=useState();
    const [city,setCity]=useState();
    const [desc,setDesc]=useState();
    const [file,setFile]=useState();
    const [url, setUrl]=useState();
    const [tourPlace,setTourPlace]=useState([]);
    const stateHandler=(e)=>{setState(e.target.value)}
    const cityHandler=(e)=>{setCity(e.target.value)}
    const descHandler=(e)=>{setDesc(e.target.value)}
    const imageHandler=(e)=>{setFile(e.target.files[0])}
    const urlHandler=(e)=>{setUrl(e.target.value)}
    const onSubmit=(e)=>{
        e.preventDefault();
        const formData=new FormData();
        formData.append('state',state);
        formData.append('city',city);
        formData.append('desc',desc);
        formData.append('file',file);
        formData.append('url',url);
        fetch("http://localhost:9999/tourPlaceDetails",{
            method:"POST",
            body:formData,
            // headers:{
            //     "Content-Type":"application/json",
            // },
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setTourPlace([...tourPlace,res]);
        })
        .catch(err=>{
            //console.log(err);
        })
    }

    useEffect(()=>{
        fetch("http://localhost:9999/tourPlaceDetails",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setTourPlace(res);
        })
    },[]);

    const deleteHandler = (itemId,indx) => {
        const idToDelete = itemId;
        const itemIndx=indx;
        fetch(`http://localhost:9999/tourPlaceDetails/${idToDelete}`, {
          method: "DELETE", credentials: "include"  
        }).then((res) => {
          //console.log("Got successfully DELETE");
          tourPlace.splice(itemIndx, 1);
          setTourPlace([...tourPlace]);
          //console.log(res);
        });
      };
    return (
        <>
            <div className="container mt-3 login-style">
                <div className="row justify-content-center shadow-lg p-3 mb-5 bg-white rounded">
                    <div className="col-8">
                        <h3 className="head-txt mb-3 text-center">Tour Place</h3>
                        <Form onSubmit={onSubmit}>
                        <FormGroup>
                                <Label for="exampleEmail">State</Label>
                                <Input type="text" name="email" id="exampleEmail" onChange={stateHandler} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleEmail">City</Label>
                                <Input type="text" name="email" id="exampleEmail" onChange={cityHandler} placeholder="with a placeholder" />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Description</Label>
                                <Input type="textarea" name="text" id="exampleText" onChange={descHandler} />
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleFile">Image</Label>
                                <Input type="file" name="file" id="exampleFile" onChange={imageHandler} />
                                <FormText color="muted">
                                    This is some placeholder block-level help text for the above input.
                                    It's a bit lighter and easily wraps to a new line.
                                </FormText>
                            </FormGroup>
                            <FormGroup>
                                <Label for="exampleText">Url</Label>
                                <Input type="text" name="text" id="exampleText" onChange={urlHandler} placeholder="wikipedia url"/>
                            </FormGroup>
                            <Button type="submit" color="danger">Save</Button>
                        </Form>
                        {/* <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                            <button type="button" className="btn btn-danger mt-1">Save</button>

                        </div> */}
                        {/* {msg?<span style={{color:"green"}}>Login Successfull!> to go ahead.</span>:null} */}
                    </div>
                </div>
            </div>
            <Table size="sm">
      <thead>
        <tr>
          <th>Sr No.</th>
          <th>State</th>
          <th>City</th>
          <th>Description</th>
          <th>Image</th>
          <th>Web Url</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        
            {tourPlace.map((value,indx)=>{
                return(
                    <tr key={indx}>
          <th scope="row">{indx+1}</th>
                <td>{value.state}</td>
                <td>{value.city}</td>
                <td>{value.description}</td>
                <td><img style={{width:"50px", height:"50px"}} src={"/tour-place/"+value.imageUrl} alt="" /></td>
                <td>{value.url}</td>
                <td>{value.date}</td>
                <td><Button type="button" color="danger" onClick={()=>deleteHandler(value._id, indx)}>Delete</Button></td>
        </tr>
                )
            })}
            </tbody>
            </Table>
        </>
    )
}
export default TourPlace;