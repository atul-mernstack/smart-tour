import React from 'react';
import {Link, useHistory} from 'react-router-dom';
import './style.css';


function Header(props) {
  const history=useHistory();
  const homeUrl=()=>{
    history.push('/Online-hotels-booking');
  }
  
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-danger">
  <div className="container-fluid">
  {props.hotelUrl?<Link className="navbar-brand brand-txt" to="#" onClick={homeUrl}>ONLINE HOTELS BOOKING</Link>
    :<Link className="navbar-brand brand-txt" to="/">SMART TOUR</Link>}
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse justify-content-end mr-5 mx-5" id="navbarText">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0 ">
        <li className="nav-item">
        {props.hotelUrl?(<Link className="nav-link nav-txt" to="/Online-hotels-booking/sing-up">SIGN UP</Link>)
          :<Link className="nav-link active nav-txt" aria-current="page" to="/">HOME</Link>}
        </li>
        <li className="nav-item">
        {props.hotelUrl?<Link className="nav-link nav-txt" to="/Online-hotels-booking/sing-in">SIGN IN</Link>
          :<Link className="nav-link nav-txt" to="/about-us">ABOUT US</Link>}
        </li>
        <li className="nav-item">
        {props.hotelUrl?<Link className="nav-link nav-txt" to="/Online-hotels-booking/support">SUPPORT</Link>
          :<Link className="nav-link nav-txt" to="/tourist-place">TOURIST PLACES</Link>}
        </li>
        <li className="nav-item">
        {props.hotelUrl?<Link className="nav-link nav-txt" to="/Online-hotels-booking/ViewHistory">VIEW HISTORY</Link>
          :<Link className="nav-link nav-txt" to="/gallery">GALLERY</Link>}
        </li>
        <li className="nav-item">
        {props.hotelUrl?<Link className="nav-link nav-txt" to="/Online-hotels-booking/contact-us">CONTACT US</Link>
          :<Link className="nav-link nav-txt" onClick={props.hotelsHandler} to="/online-hotels-booking">ONLINE HOTELS BOOKING</Link>}
        </li>
        <li className="nav-item">
        {!props.hotelUrl?<Link className="nav-link nav-txt" to="/contact-us">CONTACT US</Link>:null}
        </li>
      </ul>
      
    </div>
  </div>
</nav>
  );
}

export default Header;
