import React, { useState} from 'react';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import '../App/App.css';
import Navigation from '../Navigation';
import Home from '../Home';
import About from '../About';
import Tourist from '../TouristPlace';
import Gallery from '../Gallery';
import OnlineHotelBooking from '../Online-hotels-booking';
import Contacts from '../Contacts';
import Footer from '../Footer';
import 'bootstrap/dist/css/bootstrap.min.css';
//import HNavigation from '../Online-hotels-booking/HNavigation';
import SignIn from '../Online-hotels-booking/SignIn';
import SignUp from '../Online-hotels-booking/SignUp';
import Support from '../Online-hotels-booking/Support';
import ViewHistory from '../Online-hotels-booking/ViewHistory';
import HContact from '../Online-hotels-booking/Contact';
import Admin from '../Admin';
import Home1 from '../Admin/home';
import TourPlace from '../Admin/tourPlace';
import Emergency from '../Footer/emergency-services';
import Dos from '../Footer/dos';

function App() {
  const [hotelUrl,setHotelUrl]=useState(false);
  const [admin,setAdmin]=useState(true);
  const [footer,setFooter]=useState(true);
  const hotelsHandler=()=>{
  
  }


  return (
    <BrowserRouter>
    
    {admin?<Navigation hotelsHandler={hotelsHandler} hotelUrl={hotelUrl}/>:null}
      <Switch>
      <Route exact path="/" component={Home}/>
      <Route exact path="/about-us" component={About}/>
      <Route exact path="/Admin"><Admin setAdmin={setAdmin}/></Route>
      <Route exact path="/tourist-place" component={Tourist}/>
      <Route exact path="/gallery" component={Gallery}/>
      <Route exact path="/contact-us" component={Contacts}/>
      <Route exact path="/Online-hotels-booking"><OnlineHotelBooking setFooter={setFooter} setHotelUrl={setHotelUrl}/></Route>
      <Route exact path="/admin/home"><Home1/></Route>
      <Route exact path="/admin/tourPlace"><TourPlace/></Route>
      <Route exact path="/Online-hotels-booking/sing-up"><SignUp setHotelUrl={setHotelUrl} setFooter={setFooter}/></Route>
      <Route exact path="/Online-hotels-booking/sing-in"><SignIn setHotelUrl={setHotelUrl} setFooter={setFooter}/></Route>
      <Route exact path="/Online-hotels-booking/hotels/sing-up" component={SignUp}/>
      <Route exact path="/Online-hotels-booking/hotels/sing-in" component={SignIn}/>
      <Route exact path="/Online-hotels-booking/support"><Support setHotelUrl={setHotelUrl} setFooter={setFooter}/></Route>
      <Route exact path="/Online-hotels-booking/ViewHistory"><ViewHistory setHotelUrl={setHotelUrl} setFooter={setFooter}/></Route>
      <Route exact path="/Online-hotels-booking/contact-us"><HContact setHotelUrl={setHotelUrl} setFooter={setFooter}/></Route>
      <Route exact path="/emergency-services"><Emergency/></Route>
      <Route exact path="/do's-and-don'ts"><Dos/></Route>
      <Route exact path="/*" component={PageNotFound}/>
      </Switch>  
      {admin && footer?<Footer/>:null}    
    </BrowserRouter>
  );
}

function PageNotFound(){
  return(
    <>
      <div className="container mt-3" >
                <div className="row">
                    <div className="col-12">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded text-center" style={{height:"500px"}}>
                          <span><h4 className="justify-content-center mt-5">404, Page Not Found</h4>That's an error</span>
                            <p><br/>The requested URL was not found on this<br/> server. That's all we know.</p>
                            
                        </div>
                    </div>
                </div>
        </div>
    </>
  );
}
export default App;
