import Item from './Item';
import Carousel from "react-elastic-carousel";
import React,{useEffect,useState} from 'react';

import './style.css';
function Home() {
    return (<>
        
         <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel">
            <ol className="carousel-indicators">
                <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" className="active"></li>
                <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"></li>
                <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"></li>
            </ol>
            <div className="carousel-inner">
                <div className="carousel-item active" data-bs-interval="0">
                    <img src={"/slide-img/slide1.jpg"} className="d-block w-100 img-height" alt="..." />
                    <div className="carousel-caption d-none d-md-block">
                        {/* <h5>First slide label</h5>
                        <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
                    </div>
                </div>
                <div className="carousel-item" data-bs-interval="0">
                    <img src={"/slide-img/slide2.jpg"} className="d-block w-100 img-height" alt="..." />
                    <div className="carousel-caption d-none d-md-block">
                        
                    </div>
                </div>
                <div className="carousel-item" data-bs-interval="0">
                    <img src={"/slide-img/slide3.jpg"} className="d-block w-100 img-height" alt="..." />
                    <div className="carousel-caption d-none d-md-block">
                        
                    </div>
                </div>
            </div>
            <a className="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-bs-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                 <span className="visually-hidden"></span>{/*Previous */}
            </a>
            <a className="carousel-control-next" href="#carouselExampleCaptions" role="button" data-bs-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                 <span className="visually-hidden"></span>{/*Next */}
            </a>
            <div className="color-strip bg-danger"></div>
        </div> 
        
        <div id="bg-img">
            <div className="container">
                <div className="row">
                    <div className="col-md-6 mt-5">
                        <div className="shadow-lg p-3 mb-5 bg-white rounded">
                        <h2>THE HERITAGE ARC</h2>
                        <h4>A UNIQUE OPPORTUNITY TO EXPLORE TURIST PLACES AND HERITAGE</h4>
                        <p>Embedded in the heart of India is Uttar Pradesh,
                        a land where cultures have evolved and religions emerge.
                        The greatness of Uttar Pradesh lies not only in this confluence,
                        but also in the emergence of cultural and religious traditions along
                        some of the greatest rivers in the Indian sub-continent – the Ganga and
                        the Yamuna.Through out history, great cities have emerged and established
                        along great rivers. Within India, the Ganga and the Yamuna have nurtured a
                        culture because of which religious faith, rituals, culture and intellectual
                                enlightenment have evolved in places along the two rivers.</p>
                                </div>
                    </div>
                    <div className="col-md-6 mt-5">
                    <div className="shadow-lg p-3 mb-5 bg-white rounded">
                    
                        
                        <img src={'/ram-mandir-temple-image.jpg'} style={{width:"100%", height:"350px"}} alt=""/>
                    
                    
                    </div>
                    </div>
                </div>
            </div>
        </div>
        {/* <section className="mt-5 imp-web-link">
            <h3 className="text-danger" id="txt">Famous Tourist Places</h3>
            <div className="container">
                <div className="row ">
                    <div className="col-md-3 imp-web"><a><img src={img1} /></a></div>
                    <div className="col-md-3 imp-web"><a><img src={img2} /></a></div>
                    <div className="col-md-3 imp-web"><a><img src={img3} /></a></div>
                    <div className="col-md-3 imp-web"><a><img src={img6} /></a></div>
                </div>
            </div>
        </section> */}
        <FamousPlaces/>
    </>
    );
}

function FamousPlaces() {
    const [image,setImage]=useState([]);
    const breakPoints = [
        { width: 1, itemsToShow: 1 },
        { width: 550, itemsToShow: 2 },
        { width: 768, itemsToShow: 3 },
        { width: 1200, itemsToShow: 4 },
      ];
      useEffect(()=>{
        fetch("http://localhost:9999/gallery",{
            credentials:"include",
        })
        .then(res=>res.json())
        .then(res=>{
            //console.log(res);
            setImage(res);
        })
    },[]);
    return (
      <>
        <h3 className="text-danger mt-5" id="txt">Famous Tourist Places</h3>
        <div className="famous-places">
          <Carousel breakPoints={breakPoints}>
              {image.map((value,index)=>(
                  index<8?<Item key={index}><img style={{width:"100%",height:"100%"}} src={"/gallery/"+value.imageUrl} alt=""/></Item>:null
              ))}
            
          </Carousel>
        </div>
      </>
    );
  }
export default Home;